package bai7.code;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Nhập dữ liệu theo cấu trúc [Loại phòng] [Số đêm ở] : ");
        String line = scanner.nextLine().trim();
        String[] parts = line.split(" ");

        String loai   = parts[0];
        int sodem     = Integer.parseInt(parts[1]);

        room room; // khởi tạo 1 biến kiểu room
        if (loai.equals("S")) {
            room = new Standard(sodem);
        } else {
            room = new VIP(sodem);
        }

        System.out.println("Tổng tiền phải trả : " + (long) room.tinhTien());

        scanner.close();
    }
}
