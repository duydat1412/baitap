package bai7.code;

public class room {
    public double count;

    public room(int count) {
        this.count=count;
    }
    public double tinhTien() {
        return 0;
    }

    public String getType() {
        return "Room";
    }

}
