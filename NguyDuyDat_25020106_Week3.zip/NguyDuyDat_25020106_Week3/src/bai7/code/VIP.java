package bai7.code;

public class VIP extends room {
    private static final double GIA_MOT_DEM = 2000000;

    public VIP(int sodem) {
        super(sodem);
    }

    @Override
    public double tinhTien() {
        return count * GIA_MOT_DEM; // không giảm giá
    }

    @Override
    public String getType() {
        return "VIP";
    }
}
