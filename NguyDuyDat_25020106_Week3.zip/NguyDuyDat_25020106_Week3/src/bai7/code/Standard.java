package bai7.code;

public class Standard extends room{
    private static final double GIA_MOT_DEM = 500000;

    public Standard(int sodem) {
        super(sodem);
    }

    @Override
    public double tinhTien() {
        double tongTien = count * GIA_MOT_DEM;
        if (count > 3) {
            tongTien = tongTien * 0.95; // giảm 5%
        }
        return tongTien;
    }

    @Override
    public String getType() {
        return "Standard";
    }
}
