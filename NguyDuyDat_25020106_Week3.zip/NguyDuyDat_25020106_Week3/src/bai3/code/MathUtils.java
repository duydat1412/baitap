package bai3.code;

public class MathUtils {
    public int sum(int a, int b) {
        return (a+b);
    }
}
