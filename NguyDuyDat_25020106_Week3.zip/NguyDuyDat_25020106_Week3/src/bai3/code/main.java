package bai3.code;

public class main {
    public static void main(String[] args) {
        MathUtils m = new AdvancedMath();
        System.out.println(m.sum(5,5));
//        System.out.println(m.sum(5.5,5.5));
    }
}
