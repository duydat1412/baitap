## Giải thích:
Trong chương trình:
- `Dòng A` sẽ cho ra 20 vì hàm `sum` đã được OVERRIDE ở lớp `AdvancedMath` nên giá trị trả về sẽ là `a+b+10`.
- Bỏ comment `Dòng B` thì sẽ báo lỗi vì :
+ Biến `m` có kiểu tham chiếu là `MathUtils` (lớp cha).
+ Lớp `MathUtils` **chỉ có** phương thức `sum(int a, int b)`, **không có** phương thức `sum(double a, double b)`.
+ Mặc dù đối tượng thực tế `AdvancedMath` có phương thức `sum(double a, double b)` ,nhưng trình biên dịch chỉ nhìn vào **kiểu tham chiếu** để kiểm tra sự tồn tại của phương thức.
+ Vì `MathUtils` không có phiên bản `sum(double, double)` nên trình biên dịch báo lỗi.