## Giải thích :

**Biên dịch chương trình sẽ không xảy ra lỗi vì :**

+ Trình biên dịch chỉ kiểm tra quan hệ kế thừa giữa các lớp.

+ Vì `Dog` và `Cat` đều là lớp con của `Animal`, trình biên dịch cho rằng việc ép kiểu từ `Animal` sang `Cat` là hợp lệ về mặt cú pháp.

+ Kiểm tra này được gọi là `compile-time type checking.`

**Khi chạy chương trình lại xảy ra lỗi vì :**

+ a là tham chiếu kiểu `Animal` nhưng đối tượng thực tế là `Dog`.

+ Khi ép kiểu `(Cat) a`, JVM kiểm tra đối tượng thực tế có phải là `Cat` hay không.

+ `Dog` không phải là `Cat` → JVM ném `ClassCastException`.

*Ép kiểu (casting) là ép kiểu đối tượng, không phải ép kiểu tham chiếu.*