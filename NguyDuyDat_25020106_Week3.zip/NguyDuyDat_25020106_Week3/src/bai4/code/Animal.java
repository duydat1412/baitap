package bai4.code;

public class Animal {
    public Animal() {
        System.out.println("Da tao 1 doi tuong Animal");
    }
    public void makeSound() {
        System.out.println("Animal sound");
    }
}
