package bai4.code;

public class Duck extends Animal {

}
