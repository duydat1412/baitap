package bai6.code;
import java.time.LocalDate;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("nhập số sản phẩm cần tạo: ");
        int n = Integer.parseInt(scanner.nextLine().trim()); // loại bỏ khoảng trống và chuyển string sang int

        Product[] products = new Product[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Nhập thông tin sản phẩm : ");
            String line = scanner.nextLine().trim();
            char type = line.charAt(0); // lấy kí tự đầu tiên của chuỗi nhaajp vào

            int firstQuote = line.indexOf('"');   //indexOf và lastIndexOf trả về index của dấu ngoặc kép trong input
            int lastQuote = line.lastIndexOf('"');
            String name = line.substring(firstQuote + 1, lastQuote); //substring là cắt chuỗi từ start=firstQuote tới end = lastQuote , đoạn này để lấy name

            String[] numbers = line.substring(lastQuote + 1).trim().split("\\s+"); //substring cắt chuỗi từ sau lastQuote tới hết, trim() xóa khoảng trắng thừa ở đầu và cuối,
            // split(\\s+) tách chuỗi thành mảng theo dấu cách (\\s+ là một hoặc nhiều khoảng cách)

            if (type == 'E') {
                double basePrice = Double.parseDouble(numbers[0]); //truy cập mảng đã lấy được ở trên để gán giá trị cho các biến
                double phiBaoHanh      = Double.parseDouble(numbers[1]);
                products[i] = new Electronics(name, basePrice, phiBaoHanh);
            } else {
                double basePrice = Double.parseDouble(numbers[0]);
                LocalDate ngayHetHan   = LocalDate.parse(numbers[1]);
                products[i] = new Foods(name,basePrice,ngayHetHan);
            }
        } //1 vòng for tạo được 1 product

        // In hóa đơn
        double total =0;
        for (Product p : products) {
            p.show();
            total += p.calculateFinalPrice();
        }
        System.out.println("Total = " +total);

        scanner.close();
    }
}
