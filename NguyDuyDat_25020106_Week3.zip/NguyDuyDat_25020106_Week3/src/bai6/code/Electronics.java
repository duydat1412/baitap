package bai6.code;

public class Electronics extends Product{
    public double phiBaoHanh;

    public Electronics(String name,double basePrice,double phiBaoHanh) {
        super(name,basePrice);
        this.phiBaoHanh=phiBaoHanh;
    }
    @Override
    public double calculateFinalPrice() {
        return basePrice + (basePrice * 1/10) + phiBaoHanh;
    }
    @Override
    public void show() {
        System.out.println(name + " - Electronics - " + calculateFinalPrice());
    }
    @Override
    public String getType() {
        return "Electronics";
    }

}
