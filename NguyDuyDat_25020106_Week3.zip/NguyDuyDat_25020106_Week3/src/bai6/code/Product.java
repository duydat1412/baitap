package bai6.code;

public class Product {
    public String id;
    public String name;
    public double basePrice;

    public Product(String name, double basePrice) {
        this.name=name;
        this.basePrice=basePrice;
    }
    public String getType() {
        return "";
    }
    public double calculateFinalPrice() {
        return 0.0;
    }
    public void show() {
        System.out.println("");
    }
    public String getName() {
        return name;
    }
}
