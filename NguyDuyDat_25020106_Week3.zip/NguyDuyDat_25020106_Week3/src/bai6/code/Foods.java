package bai6.code;
import java.time.LocalDate;

public class Foods extends Product{
    public LocalDate ngayHetHan;

    public Foods(String name,double basePrice,LocalDate ngayHetHan) {
        super(name,basePrice);
        this.ngayHetHan=ngayHetHan;
    }
    @Override
    public double calculateFinalPrice() {
        LocalDate currentDay= LocalDate.now(); // lấy ngày hiện tại
        long daysLeft = currentDay.until(ngayHetHan).getDays(); // tính số ngày còn lại đến khi hết hạn

        if (daysLeft < 7) {
            return basePrice*0.8;
        }else return basePrice;
    }
    @Override
    public void show() {
        System.out.println(name + " - Foods - " + calculateFinalPrice());
    }
    @Override
    public String getType() {
        return "Foods";
    }

}
