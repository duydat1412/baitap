package bai9.code;

public class Invoice implements IPayable{
    public String itemName;
    public int quantity;
    public double pricePerItem;

    public Invoice(String itemName, int quantity, double pricePerItem) {
        this.itemName=itemName;
        this.quantity=quantity;
        this.pricePerItem=pricePerItem;
    }
    @Override
    public double getPaymentAmount() {
        return quantity*pricePerItem;
    }
    public void paymentShow() {
        System.out.println("Invoice " + itemName +" - " + "Payment: " + getPaymentAmount());
    }
}
