package bai9.code;
import java.util.Scanner;
public class main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập số lượng đối tượng cần thanh toán : " );
        int n = Integer.parseInt(sc.nextLine().trim());

        IPayable[] payableList = new IPayable[n];

        for (int i = 0;i<n;i++){
            System.out.println("Nhập thông tin đối tượng : ");
            String[] parts = sc.nextLine().trim().split("\\s+");
            String type = parts[0];

            if (type.equals("S")) {

                String id = parts[1];
                String name = parts[2];
                int workingHours = Integer.parseInt(parts[3]);
                int hourlyRate = Integer.parseInt(parts[4]);
                payableList[i] = new PartTimeStaff(id,name,workingHours,hourlyRate);
            } else {
                String itemName = parts[1];
                int quantity = Integer.parseInt(parts[2]);
                double pricePerItem = Double.parseDouble(parts[3]);
                payableList[i] = new Invoice(itemName,quantity,pricePerItem);
            }
        }
        double total = 0.0;
        for (IPayable p : payableList) {
            p.paymentShow();
            total += p.getPaymentAmount();
        }
        System.out.println("Total Payment = "+total);
        sc.close();
    }
}
