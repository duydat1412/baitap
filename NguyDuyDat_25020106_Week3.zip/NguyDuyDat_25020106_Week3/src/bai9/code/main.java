package bai9.code;

import java.util.Scanner;
public class main {
    public static  void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập thông tin sản phẩm 1 ");
        System.out.print("Tên: ");
        String name1 = sc.nextLine();
        System.out.print("Giá: ");
        double price1 = sc.nextDouble();
        System.out.print("Số lượng: ");
        int quantity1 = sc.nextInt();
        System.out.print("Giảm giá: ");
        double discount1 = sc.nextDouble();
        sc.nextLine();
        Product p1 = new Product(name1,price1,quantity1,discount1);
        System.out.println("Tạo thành công sản phẩm " + name1);
        System.out.println("-----------------------------");

        System.out.println("Nhập thông tin sản phẩm 2 ");
        System.out.print("Tên: ");
        String name2 = sc.nextLine();
        System.out.print("Giá: ");
        double price2 = sc.nextDouble();
        System.out.print("Số lượng: ");
        int quantity2 = sc.nextInt();
        System.out.print("Giảm giá: ");
        double discount2 = sc.nextDouble();
        sc.nextLine();
        Product p2 = new Product(name2,price2,quantity2,discount2);
        System.out.println("Tạo thành công sản phẩm " + name2);
        System.out.println("-----------------------------");
        System.out.println("Nhập số lượng cần mua cho p1 : ");
        int amount1 = sc.nextInt();
        p1.sell(amount1);
        System.out.println("Nhap so luong can mua cho p2 : ");
        int amount2 = sc.nextInt();
        p2.sell(amount2);
        System.out.println("-----------------------------");
        System.out.println("Final price của p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price của p2 :");
        System.out.println(p2.calculateFinalPrice());
        Product.updateTaxRate(0.08);
        System.out.println("-----------------------------");
        System.out.println("Final price sau khi thay taxRate ");
        System.out.println("Final price của p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price của p2 :");
        System.out.println(p2.calculateFinalPrice());
        p1.updateDiscount(10.0);
        System.out.println("-----------------------------");
        System.out.println("Final price sau khi thay discount của p1");
        System.out.println("Final price của p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price của p2 :");
        System.out.println(p2.calculateFinalPrice());
        System.out.println("-----------------------------");
        System.out.println("Tổng doanh thu là : ");
        System.out.println(Product.totalRevenueGet());


    }
}

