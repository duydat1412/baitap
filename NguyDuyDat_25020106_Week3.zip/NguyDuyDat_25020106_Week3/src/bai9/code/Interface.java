package bai9.code;

interface IPayable {
    double getPaymentAmount();
    void paymentShow();
}
