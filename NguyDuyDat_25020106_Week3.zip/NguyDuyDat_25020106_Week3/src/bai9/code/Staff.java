package bai9.code;

public abstract class Staff implements IPayable {
    public String id;
    public String name;

    public Staff(String id, String name) {
        this.id=id;
        this.name=name;
    }
    public void setId(String id1) {
        this.id=id1;
    }
    public void setName(String name1) {
        this.id=name1;
    }
    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
}
