package bai9.code;
public class Product {
    private String name;
    private double price;
    private int quantity;
    private double discount;

    private static double taxRate = 0.1;
    private static double totalRevenue = 0.0;

    public Product(String name, double price, int quantity, double discount) {
        this.name=name;
        this.price=price;
        this.quantity=quantity;
        this.discount=discount;
    }
    public static void updateTaxRate(double newRate) {
        taxRate = newRate;
    }
    public double calculateFinalPrice() {
        double finalPrice = (price - discount) * (1+taxRate);
        return finalPrice;
    }
    public void updateDiscount(double newDiscount) {
        this.discount=newDiscount;
    }
    public void sell(int amount) {
        if (amount<= quantity) {
            quantity -= amount;
            totalRevenue += (amount * ((price - discount) * (1+taxRate)));
            System.out.println("Mua hang thanh cong!");
        } else System.err.println("Khong con hang trong kho");
    }
    public static double totalRevenueGet() {
        return totalRevenue;
    }
}

