package bai9.code;

public class PartTimeStaff extends Staff implements IPayable{
    public int workingHours;
    public double hourlyRate;

    public PartTimeStaff(String name, String id, int workingHours, int hourlyRate) {
        super(name,id);
        this.workingHours=workingHours;
        this.hourlyRate=hourlyRate;
    }
    @Override
    public double getPaymentAmount() {
        return workingHours*hourlyRate;
    }
    public void paymentShow() {
        System.out.println("PartTimeStaff " + name +" - " + "Payment: " + getPaymentAmount());
    }
}
