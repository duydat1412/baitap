**Sau khi xóa constructor mặc định ở lớp Person đi, thay bằng constructor có tham số, thì lớp Employee và Manager sẽ báo lỗi vì:**

+Trong Java, nếu lớp cha không có constructor mặc định, lớp con sẽ không thể tự động gọi constructor cha. 

+Trình biên dịch sẽ báo lỗi vì nó không biết truyền tham số gì cho constructor của lớp cha.
