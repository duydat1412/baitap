package bai1.code;

public class main {
    public static void  main(String[] args) {
        Manager m = new Manager();
    }
}
