```mermaid
classDiagram
    class Employee {
        - String name
        - String birthday
        - String msnv
        + Employee(name)
        + getName() String
        + getType() String
        + tinhLuong() double
        + show() void
    }

    class FullTimeEmployee {
        - double baseSalary
        - double bonus
        - double penalty
        + tinhLuong() double
        + show() void
        + getType() String
    }

    class PartTimeEmployee {
        - double workingHours
        - double hourlyRate
        + tinhLuong() double
        + show() void
        + getType() String
    }

    Employee <|-- FullTimeEmployee
    Employee <|-- PartTimeEmployee
```