package bai5.code;

public class PartTimeEmployee extends Employee {
    public double workingHours;
    public double hourlyRate;

    public PartTimeEmployee(String name,
                            double workingHours, double hourlyRate) {
        super(name);
        this.workingHours=workingHours;
        this.hourlyRate=hourlyRate;
    }
    public void setWorkingHours(double newWorkingHours) {
        this.workingHours=newWorkingHours;
    }
    public void setHourlyRate(double newHourlyRate) {
        this.hourlyRate = newHourlyRate;
    }
    @Override
    public double tinhLuong() {
        return workingHours*hourlyRate;
    }

    @Override
    public String getType() {
        return "Part-time";
    }
    @Override
    public void show() {
        System.out.println(name + " - Part-time - " + tinhLuong());
    }
}
