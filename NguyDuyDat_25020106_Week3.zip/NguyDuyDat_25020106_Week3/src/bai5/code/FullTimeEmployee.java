package bai5.code;

public class FullTimeEmployee extends Employee {
    private double baseSalary;
    private double bonus;
    private double penalty;

    public FullTimeEmployee(String name,
                            double baseSalary, double bonus, double penalty) {
        super(name);
        this.baseSalary = baseSalary;
        this.bonus = bonus;
        this.penalty = penalty;
    }

    public void setBaseSalary(double newBaseSalary) {
        this.baseSalary = newBaseSalary;
    }

    public void setBonus(double newBonus) {
        this.bonus = newBonus;
    }

    public void setPenalty(double newPenalty) {
        this.penalty = newPenalty;
    }

    @Override
    public double tinhLuong() {
        return baseSalary + (bonus - penalty);
    }

    @Override
    public String getType() {
        return "Full-time";
    }
    @Override
    public void show() {
        System.out.println(name + " - Full-time - " + tinhLuong());
    }
}