package bai5.code;

public class Employee {
    public String name;
    public String birthday;
    public String msnv;

    public Employee(String name) {
        this.name=name;
    }
    public String getName() {
        return name;
    }
    public double tinhLuong() {
        return 0;
    }
    public String getType() {
        return "";
    }
    public void show() {
        System.out.println("");
    }
}
