package bai5.code;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("nhập số nhân viên cần tạo: ");
        int n = Integer.parseInt(scanner.nextLine().trim()); // loại bỏ khoảng trống và chuyển string sang int

        Employee[] employees = new Employee[n];

        for (int i = 0; i < n; i++) {
            System.out.println("Nhập thông tin nhân viên: ");
            String line = scanner.nextLine().trim();
            char type = line.charAt(0); // lấy kí tự đầu tiên của chuỗi nhaajp vào

            int firstQuote = line.indexOf('"');   //indexOf và lastIndexOf trả về index của dấu ngoặc kép trong input
            int lastQuote = line.lastIndexOf('"');
            String name = line.substring(firstQuote + 1, lastQuote); //substring là cắt chuỗi từ start=firstQuote tới end = lastQuote

            String[] numbers = line.substring(lastQuote + 1).trim().split("\\s+"); //substring cắt chuỗi từ sau lastQuote tới hết, trim() xóa khoảng trắng thừa ở đầu và cuối,
                                                                                                    // split(\\s+) tách chuỗi thành mảng theo dấu cách (\\s+ là một hoặc nhiều khoảng cách)

            if (type == 'F') {
                double baseSalary = Double.parseDouble(numbers[0]); //truy cập mảng đã lấy được ở trên để gán giá trị cho các biến
                double bonus      = Double.parseDouble(numbers[1]);
                double penalty    = Double.parseDouble(numbers[2]);
                employees[i] = new FullTimeEmployee(name, baseSalary, bonus, penalty); // tạo đối tượng tương ứng với F=FullTime hoặc P=PartTime
            } else {
                double workingHours = Double.parseDouble(numbers[0]);
                double hourlyRate   = Double.parseDouble(numbers[1]);
                employees[i] = new PartTimeEmployee(name, workingHours, hourlyRate);
            }
        } //1 vòng for tạo được 1 employee

        // In bảng lương
        for (Employee emp : employees) {
            emp.show();
        }

        scanner.close();
    }

}
