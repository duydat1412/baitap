package bai10.code;

public class Developer extends Employee{
    int overtimeHours;

    public Developer(String name, double baseSalary,int overtimeHours) {
        super(name,baseSalary);
        this.overtimeHours=overtimeHours;
    }
    @Override
    public double calculateBonus() {
        return 0.1*baseSalary + (overtimeHours*200000);
    }
    public String getType() {
        return "D";
    }
}
