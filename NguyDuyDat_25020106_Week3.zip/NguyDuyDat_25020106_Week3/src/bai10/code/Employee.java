package bai10.code;

public class Employee {
    public String name;
    public double baseSalary;

    public Employee(String name, double baseSalary) {
        this.name=name;
        this.baseSalary=baseSalary;
    }
    public double calculateBonus() {
        return baseSalary*0.1;
    }
    public String getName() {
        return this.name;
    }
    public String getType() {
        return "E";
    }
}
