package bai10.code;
import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<Employee> employees =new ArrayList<Employee>();

        System.out.println("Nhập số lượng nhân viên cần tạo : ");
        int n = Integer.parseInt(sc.nextLine().trim());

        for (int i = 0 ; i<n ; i++) {
            System.out.println("Nhập thông tin nhân viên : ");
            String line = sc.nextLine();
            String[] parts = line.split(" ");

            String type = parts[0];
            if (type.equals("E")) {
                String name = parts[1];
                double baseSalary = Double.parseDouble(parts[2]);
                employees.add(new Employee(name,baseSalary));
            } else if (type.equals("D")) {
                String name = parts[1];
                double baseSalary = Double.parseDouble(parts[2]);
                int overtimeHours = Integer.parseInt((parts[3]));
                employees.add(new Developer(name,baseSalary,overtimeHours));
            } else {
                String name = parts[1];
                double baseSalary = Double.parseDouble(parts[2]);
                int bugsFound = Integer.parseInt(parts[3]);
                employees.add(new Tester(name,baseSalary,bugsFound));
            }
        }
        for (Employee e : employees) {
            if (e.getType().equals("E")) {
                System.out.println(e.getName() + " - Bonus : " + e.calculateBonus());
                System.out.println(" ");
            }
            if (e.getType().equals("D")) {
                System.out.println(e.getName() + " - Bonus : " + e.calculateBonus());
                System.out.println("Tặng khóa học AWS");
                System.out.println(" ");
            }
            if (e.getType().equals("T")) {
                System.out.println(e.getName() + " - Bonus : " + e.calculateBonus());
                System.out.println("Tặng tool Test");
                System.out.println(" ");
            }
        }
        sc.close();
    }
}
