## Tóm tắt ý tưởng chính
Mô phỏng sự tương tác giữa trung tâm điều khiển (Hub) và các thiết bị đèn thông minh.

## Hướng tiếp cận và Ưu điểm
Áp dụng **Method Overloading** cho `setBrightness` (nhận tham số kiểu `int` hoặc `String` preset). Minh họa sự **tương tác giữa các đối tượng (Object Interaction)** khi `SmartLight` đăng ký chính nó vào `CentralHub` thông qua tham chiếu `this`.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai10.code.main