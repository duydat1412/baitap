# Bài 8: Object Reference và Garbage Collection

## Tóm tắt ý tưởng chính
Mô tả một lớp có thuộc tính tự tham chiếu đến chính lớp đó và tìm hiểu về cơ chế quản lý bộ nhớ của Java.

## Hướng tiếp cận và Ưu điểm
Minh họa **Self-referencing relationships**. Thuộc tính `me` kiểu `Person` bên trong lớp `Person` cho phép xây dựng các cấu trúc dữ liệu liên kết hoặc các mối quan hệ logic giữa các thực thể của cùng một loại.
Cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và hiểu rõ hơn về cách JVM quản lý bộ nhớ Heap và Stack.

## Cách chạy
- Sử dụng script bash: `./run.sh`
- Class chứa hàm main thực thi: `bai8.code.main`

---

## 5. Kết quả phân tích (Trả lời câu hỏi)

### 5.1. Số lượng đối tượng sau khi `setMe(p)`
- Có **1** đối tượng `Person` duy nhất tồn tại trong bộ nhớ.
- Lệnh `p.setMe(p)` không tạo ra đối tượng mới mà chỉ gán tham chiếu của đối tượng hiện tại cho thuộc tính `me` bên trong nó.

### 5.2. Trạng thái sau lệnh `p = null` và cơ chế Garbage Collection
- Đối tượng **không bị xóa ngay lập tức**.
- **Cơ chế:** Java sử dụng bộ dọn rác (Garbage Collector - GC) để tự động giải phóng bộ nhớ. Khi lệnh `p = null` được thực thi, đối tượng `Person` không còn bất kỳ "tham chiếu mạnh" nào từ Stack (GC Roots) trỏ tới. Mặc dù thuộc tính `me` vẫn tham chiếu đến chính nó (vòng lặp tham chiếu), nhưng vì không còn lối vào từ bên ngoài, GC sẽ đánh dấu đối tượng này là "không thể tiếp cận" (unreachable) và sẽ xóa nó trong lần chạy tới.

### 5.3. Khả năng truy cập lại đối tượng
- **Không thể truy cập lại.**
- **Giải thích:** Vì biến tham chiếu duy nhất (`p`) đã bằng `null`, chương trình không còn nắm giữ địa chỉ vùng nhớ của đối tượng đó nữa.

### 5.4. Sơ đồ bộ nhớ (Stack và Heap)

| Thời điểm | Stack (Biến `p`) | Heap (Đối tượng `Person`) |
| :--- | :--- | :--- |
| **Trước khi `p = null`** | `p` -> [Địa chỉ `0x1`] | [Địa chỉ `0x1`]: {`name`: "Dat", `me`: `0x1`} |
| **Sau khi `p = null`** | `p` -> `null` | [Địa chỉ `0x1`]: {`name`: "Dat", `me`: `0x1`} (Cô lập, chờ GC) |

- **Giải thích sơ đồ:** Ở thời điểm sau khi `p = null`, liên kết từ Stack vào Heap bị ngắt. Đối tượng ở địa chỉ `0x1` trong Heap tuy vẫn chứa tham chiếu nội bộ `me` trỏ vào chính nó, nhưng vì Stack không còn đường dẫn nào đến `0x1`, đối tượng này trở thành rác.