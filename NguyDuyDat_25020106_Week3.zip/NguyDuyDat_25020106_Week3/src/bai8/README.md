    ## Giải thích :

**Khi lấy một đối tuọng `Robot` thực chất là `DroneRobot` ra khỏi danh sách và gọi `fly()` sẽ xảy ra lỗi vì :**

+ Khi bạn lấy đối tượng ra từ danh sách `List<Robot>`, trình biên dịch (compiler) của Java chỉ coi nó là một `Robot` thông thường. 
+ Trình biên dịch sẽ nhìn vào class `Robot` xem có hàm `fly()` không, và vì không có nên nó sẽ báo lỗi gạch đỏ ngay lập tức (Compile Error), cho dù bản chất bên trong đối tượng đó thực sự là một DroneRobot.

**`DroneRobot` extends cả `Robot` và `ElectronicDevice` sẽ lỗi vì :**

+ Java có một quy tắc cốt lõi là không hỗ trợ đa kế thừa đối với Class.

**Khi chuyển `ElectronicDevice` thành `interface`, cho `DroneRobot` implements thì :**

+ Code sẽ chạy bình thường với điều kiện phải Override `turnOn()` method.

*Ép kiểu (casting) là ép kiểu đối tượng, không phải ép kiểu tham chiếu.*