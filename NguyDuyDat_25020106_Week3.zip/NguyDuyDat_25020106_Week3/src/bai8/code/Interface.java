package bai8.code;

interface Flyable {
    void fly();
}

interface Swimmable {
    void swim();
}

interface GPS {
    void getCoordinates();
}
interface ElectronicDevice {
    void turnOn();
}