package bai8.code;

import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhập số lượng robots : ");
        int n = Integer.parseInt(sc.nextLine());

        ArrayList<Robot> robots = new ArrayList<>(); //tạo list chứa các đối tượng robot

        for (int i = 0; i < n; i++) {
            System.out.println("Nhập thông tin robot : ");
            String line = sc.nextLine(); // nhận input
            String[] parts = line.split(" "); //tách input thành các phần

            String type = parts[0];
            int id = Integer.parseInt(parts[1]);
            String modelName = parts[2];

            switch (type) { //xét biến type, nếu biến type bằng case nào thì output ra cái tương ứng
                case "DR":
                    robots.add(new DroneRobot(id, modelName));
                    break;
                case "FR":
                    robots.add(new FishRobot(id, modelName));
                    break;
                case "AR":
                    robots.add(new AmphibiousRobot(id, modelName));
                    break;
                default:
                    System.out.println("Unknown robot type: " + type); // output khi không thuộc case nào
            }
        }

        for (Robot robot : robots) {
            robot.performMainTask();

            if (robot instanceof Flyable) {
                ((Flyable) robot).fly();   //ép kiểu biến robot về interface Flyable để gọi fly() do class Robot chưa implements interface.
            }
            if (robot instanceof Swimmable) {
                ((Swimmable) robot).swim();
            }
            if (robot instanceof GPS) {
                ((GPS) robot).getCoordinates();
            }
            System.out.println();
        }

        sc.close();
    }
}