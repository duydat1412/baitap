package bai8.code;

import java.util.ArrayList;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = Integer.parseInt(sc.nextLine());

        ArrayList<Robot> robots = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String line = sc.nextLine();
            String[] parts = line.split(" ");

            String type = parts[0];
            int id = Integer.parseInt(parts[1]);
            String modelName = parts[2];

            switch (type) {
                case "DR":
                    robots.add(new DroneRobot(id, modelName));
                    break;
                case "FR":
                    robots.add(new FishRobot(id, modelName));
                    break;
                case "AR":
                    robots.add(new AmphibiousRobot(id, modelName));
                    break;
                default:
                    System.out.println("Unknown robot type: " + type);
            }
        }

        // Duyệt danh sách robot
        for (Robot robot : robots) {
            robot.performMainTask();

            // Kiểm tra và gọi các kỹ năng
            if (robot instanceof Flyable) {
                ((Flyable) robot).fly();
            }
            if (robot instanceof Swimmable) {
                ((Swimmable) robot).swim();
            }
            if (robot instanceof GPS) {
                ((GPS) robot).getCoordinates();
            }
            System.out.println();
        }

        sc.close();
    }
}