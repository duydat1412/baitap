## Giải thích:
Trong chương trình:
1. Lớp `Animal` có phương thức `makeSound()` in ra `"Animal sound"`.
2. Lớp `Dog` và `Cat` **ghi đè (override)** phương thức `makeSound()` để in ra âm thanh riêng của chúng.
3. Lớp `Duck` **không ghi đè** phương thức `makeSound()`.

Khi gọi `makeSound()` trên một đối tượng thuộc kiểu `Animal`:

- Nếu đối tượng thực tế là `Dog` → gọi phiên bản `makeSound()` của `Dog`.
- Nếu đối tượng thực tế là `Cat` → gọi phiên bản `makeSound()` của `Cat`.
- Nếu đối tượng thực tế là `Duck` → **không có phiên bản riêng**, do đó phương thức được kế thừa từ lớp cha `Animal` sẽ được gọi.

Đây chính là **tính chất đa hình (polymorphism)** trong Java:
> Khi một lớp con không ghi đè phương thức của lớp cha, nó sẽ tự động kế thừa và sử dụng phương thức từ lớp cha.

---

## Kết luận:

Con vịt kêu `"Animal sound"` vì lớp `Duck` không tự định nghĩa lại âm thanh riêng, nên nó sử dụng âm thanh mặc định từ lớp `Animal`.