package bai2.code;

public class Cat extends Animal{
    @Override
    public void makeSound() {
        System.out.println("Meows meows");
    }
}
