package bai2.code;

public class main {
    public static void  main(String[] args) {
        Animal[] zoo = new Animal[4];
        zoo[0] = new Dog();
        zoo[1] = new Cat();
        zoo[2] = new Duck();
        zoo[3] = new Dog();

        for (Animal p : zoo ) {
            p.makeSound();
        }

    }
}
