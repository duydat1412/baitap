package bai6.code;

import java.util.InputMismatchException; // Nem ra khi nguoi dung nhap sai kieu du lieu (vi du: nhap chu thay vi so)
import java.util.Scanner;               // Doc du lieu tu ban phim

/**
 * Bai 6 - Bai 1: Phep chia an toan.
 *
 * Xu ly ngoai le:
 *
 * InputMismatchException:
 *   - Nem ra boi Scanner khi nextInt() gap gia tri khong phai so nguyen.
 *   - Vi du: nguoi dung nhap "abc" hoac "3.5".
 *
 * ArithmeticException:
 *   - Nem ra khi thuc hien phep chia nguyen cho 0 (a / 0).
 *   - Voi so nguyen: Java nem loi nay tu dong.
 *   - Voi so thuc (double): Java tra ve Infinity (khong nem loi).
 *
 * Khoi finally:
 *   - Luon duoc thuc thi du co ngoai le xay ra hay khong.
 *   - Thuong dung de dong tai nguyen (dong file, dong ket noi...) hoac in thong bao ket thuc.
 *
 * Cu phap try-catch-finally:
 *   try {
 *       // Code co the gay ra ngoai le
 *   } catch (ExceptionType e) {
 *       // Xu ly khi gap ngoai le cu the
 *   } finally {
 *       // Luon chay, du co loi hay khong
 *   }
 */
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Nhap so a: ");
            int a = sc.nextInt(); // Nem InputMismatchException neu nhap sai kieu

            System.out.print("Nhap so b: ");
            int b = sc.nextInt(); // Nem InputMismatchException neu nhap sai kieu

            int result = a / b;   // Nem ArithmeticException neu b = 0

            System.out.println("Ket qua: " + a + " / " + b + " = " + result);

        } catch (InputMismatchException e) {
            // Bat loi nhap lieu sai kieu
            System.out.println("Loi: Vui long nhap so nguyen hop le.");

        } catch (ArithmeticException e) {
            // Bat loi chia cho 0
            System.out.println("Loi: Khong the chia cho 0.");

        } finally {
            // Luon duoc thuc hien, du co loi hay khong
            System.out.println("Program finished.");
            sc.close(); // Dong Scanner sau khi dung xong
        }
    }
}
