package bai2.code;

public class Pair {
    public Customer customer;
    public Ticket ticket;

    public Pair(Customer customer, Ticket ticket) {
        this.customer=customer;
        this.ticket=ticket;
    }
}
