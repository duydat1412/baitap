package bai2.code;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Lớp đại diện cho Ticket hỗ trợ.
 */
public class Ticket {
    public String id;
    public String content;
    public String timestamp;

    public Ticket(String id, String content) {
        this.id = id;
        this.content = content;
        // Sử dụng LocalDateTime để lấy thời gian hiện tại và định dạng nó
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    @Override
    public String toString() {
        return "Ticket [ID=" + id + ", Nội dung=" + content + ", Thời gian=" + timestamp + "]";
    }
}
