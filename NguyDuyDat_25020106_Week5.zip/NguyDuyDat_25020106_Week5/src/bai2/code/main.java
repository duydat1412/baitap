package bai2.code;

/**
 * Lớp main mô phỏng hệ thống hỗ trợ khách hàng.
 */
public class main {
    public static void main(String[] args) {
        System.out.println("=== HỆ THỐNG HỖ TRỢ KHÁCH HÀNG ===\n");

        // 1. Khởi tạo Hàng đợi khách hàng (FIFO) và Lịch sử tin nhắn (LIFO)
        CustomerQueue customerQueue = new CustomerQueue();
        MessageHistory messageHistory = new MessageHistory();

        // 2. Mô phỏng khách hàng đến
        System.out.println("--- Giai đoạn 1: Tiếp nhận khách hàng ---");
        Customer customerA = new Customer("C001", "Nguyễn Văn A");
        Customer customerB = new Customer("C002", "Trần Thị B");

        customerQueue.addCustomer(customerA);
        customerQueue.addCustomer(customerB);
        System.out.println();

        // 3. Xử lý khách hàng đầu tiên (Khách A) - FIFO
        System.out.println("--- Giai đoạn 2: Xử lý khách hàng A ---");
        Customer processingCustomer = customerQueue.processCustomer();

        if (processingCustomer != null) {
            System.out.println("Nhân viên đang soạn tin nhắn trả lời cho " + processingCustomer.name + "...");
            
            // Gõ 3 dòng tin nhắn
            messageHistory.pushMessage("Chào bạn, tôi có thể giúp gì cho bạn?");
            messageHistory.pushMessage("Chúng tôi đã nhận được yêu cầu của bạn.");
            messageHistory.pushMessage("Yêu cầu của bạn sẽ được xử lý trong 24h (Gõ nhầm).");

            // Xem tin nhắn gần nhất
            messageHistory.viewLast();

            // Thực hiện Undo 1 dòng (LIFO)
            messageHistory.undo();

            // Xem lại sau khi undo
            messageHistory.viewLast();

            System.out.println("Xử lý xong cho " + processingCustomer.name + ".\n");
        }

        // 4. Xử lý khách hàng tiếp theo (Khách B)
        System.out.println("--- Giai đoạn 3: Xử lý khách hàng B ---");
        processingCustomer = customerQueue.processCustomer();

        if (processingCustomer != null) {
            System.out.println("Nhân viên đang soạn tin nhắn trả lời cho " + processingCustomer.name + "...");
            messageHistory.pushMessage("Chào bạn " + processingCustomer.name + ", đơn hàng của bạn đang được giao.");
            System.out.println("Xử lý xong cho " + processingCustomer.name + ".\n");
        }

        // 5. Kiểm tra khi hàng đợi rỗng
        System.out.println("--- Giai đoạn 4: Kiểm tra hàng đợi rỗng ---");
        customerQueue.processCustomer();
    }
}
