package bai2.code;

/**
 * Lớp đại diện cho Khách hàng.
 */
public class Customer {
    public String id;
    public String name;

    public Customer(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Khách hàng [ID=" + id + ", Tên=" + name + "]";
    }
}
