package bai2.code;

/**
 * Lớp đại diện cho Tin nhắn.
 */
public class Message {
    public String id;
    public String content;

    public Message(String id, String content) {
        this.id = id;
        this.content = content;
    }
}
