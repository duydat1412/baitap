package bai2.code;

import java.util.Stack;

/**
 * Lớp MessageHistory quản lý lịch sử tin nhắn trả lời của nhân viên theo cơ chế LIFO (Last In, First Out).
 * 
 * LIFO (Last In, First Out): "Vào sau, ra trước".
 * Đối tượng nào được thêm vào cuối cùng sẽ là đối tượng đầu tiên được lấy ra.
 * Tương tự như một chồng đĩa, cái đĩa đặt lên sau cùng sẽ được lấy ra đầu tiên.
 * 
 * Thư viện và hàm sử dụng:
 * - Stack: Lớp trong Java triển khai cấu trúc dữ liệu ngăn xếp.
 * - push(E item): Thêm một phần tử vào đỉnh của Stack.
 * - pop(): Lấy ra và xóa phần tử ở đỉnh của Stack (phần tử mới nhất).
 * - peek(): Xem phần tử ở đỉnh của Stack mà không xóa nó.
 * - isEmpty(): Kiểm tra xem Stack có trống không.
 */
public class MessageHistory {
    // Sử dụng Stack để quản lý lịch sử (LIFO)
    private Stack<String> history;

    public MessageHistory() {
        this.history = new Stack<>();
    }

    // Khi nhân viên gõ tin nhắn trả lời, lưu vào Stack
    public void pushMessage(String message) {
        history.push(message);
        System.out.println("Đã lưu tin nhắn: \"" + message + "\"");
    }

    // Tính năng Undo: Xóa câu gần nhất vừa gõ
    public void undo() {
        if (history.isEmpty()) {
            System.out.println("Không có tin nhắn nào để hoàn tác (Undo).");
            return;
        }
        String removed = history.pop();
        System.out.println("Đã hoàn tác (Undo) tin nhắn: \"" + removed + "\"");
    }

    // Tính năng View Last: Xem lại câu vừa gõ mà không xóa
    public void viewLast() {
        if (history.isEmpty()) {
            System.out.println("Lịch sử tin nhắn trống.");
            return;
        }
        System.out.println("Tin nhắn gần nhất: \"" + history.peek() + "\"");
    }
}
