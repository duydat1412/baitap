package bai2.code;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Lớp CustomerQueue quản lý hàng đợi khách hàng theo cơ chế FIFO (First In, First Out).
 * 
 * FIFO (First In, First Out): "Vào trước, ra trước". 
 * Đối tượng nào được thêm vào hàng đợi trước sẽ được lấy ra và xử lý trước.
 * Giống như việc xếp hàng mua vé, người đến trước được phục vụ trước.
 * 
 * Thư viện và hàm sử dụng:
 * - Queue: Giao diện (interface) trong Java dùng để quản lý hàng đợi.
 * - LinkedList: Một lớp cài đặt interface Queue, hiệu quả cho việc thêm/xóa phần tử.
 * - offer(E e): Thêm một phần tử vào cuối hàng đợi. Trả về true nếu thành công.
 * - poll(): Lấy ra và xóa phần tử đầu hàng đợi. Trả về null nếu hàng đợi rống.
 * - isEmpty(): Kiểm tra xem hàng đợi có trống hay không.
 */
public class CustomerQueue {
    // Sử dụng LinkedList để triển khai Queue (FIFO)
    private Queue<Customer> queue;

    public CustomerQueue() {
        this.queue = new LinkedList<>();
    }

    // Khách hàng gửi yêu cầu -> Thêm vào hàng đợi
    public void addCustomer(Customer customer) {
        queue.offer(customer);
        System.out.println("Đã thêm khách hàng: " + customer.name + " (ID: " + customer.id + ") vào hàng đợi.");
    }

    // Nhân viên xử lý -> Lấy khách hàng ra khỏi hàng đợi
    public Customer processCustomer() {
        if (queue.isEmpty()) {
            System.out.println("Thông báo: Không còn khách hàng đợi.");
            return null;
        }
        Customer customer = queue.poll();
        System.out.println("Đang xử lý khách hàng: " + customer.name);
        return customer;
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }
}
