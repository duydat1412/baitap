package bai4.code;

/**
 * Lớp main: Chạy thử WordCounter với đoạn văn bản mẫu.
 *
 * Du lieu dau vao: "Hello world. This is a java program. Hello java, hello world."
 */
public class main {
    public static void main(String[] args) {

        // Dữ liệu đầu vào theo đề bài
        String text = "Hello world. This is a java program. Hello java, hello world.";

        System.out.println("Van ban goc: " + text);
        System.out.println();

        // --- CÁCH 2: HashMap (khuyến nghị dùng) ---
        WordCounter counter = new WordCounter();
        counter.analyze(text);
        counter.displayResult();

        // --- CÁCH 1: ArrayList (minh họa để so sánh) ---
        WordCounter.analyzeWithArrayList(text);

        // So sánh độ phức tạp
        System.out.println("\n=== SO SANH DO PHUC TAP ===");
        System.out.println("ArrayList: Moi lan them tu moi phai duyet ca danh sach -> O(n)");
        System.out.println("HashMap  : Kiem tra containsKey() bang bang bam -> O(1)");
        System.out.println("=> HashMap hieu qua hon khi van ban lon.");
    }
}
