package bai4.code;

import java.util.ArrayList;  // ArrayList: Danh sách động, truy cập qua index
import java.util.HashMap;    // HashMap: Lưu cặp key-value (từ -> số lần xuất hiện)

/**
 * Lớp WordCounter: Phân tích tần suất từ trong văn bản.
 *
 * Bài này so sánh 2 cách tiếp cận:
 *
 * CÁCH 1 - Dùng ArrayList:
 *   - Khi thêm một từ mới, phải duyệt toàn bộ danh sách để kiểm tra từ đã tồn tại chưa.
 *   - Độ phức tạp: O(n) - chậm hơn khi văn bản dài.
 *   - Ví dụ: Nếu có 1000 từ, mỗi lần thêm phải kiểm tra tối đa 1000 phần tử.
 *
 * CÁCH 2 - Dùng HashMap<String, Integer>:
 *   - Key là từ (String), Value là số lần xuất hiện (Integer).
 *   - Kiểm tra từ đã tồn tại bằng containsKey() - tra bảng băm, rất nhanh.
 *   - Độ phức tạp: O(1) trung bình - nhanh hơn nhiều so với ArrayList.
 *   - Ví dụ: Dù có 1 triệu từ, containsKey() vẫn tra ra kết quả gần như tức thì.
 *
 * Thư viện và hàm built-in sử dụng:
 *   - HashMap.containsKey(key) : Kiểm tra xem key có tồn tại trong Map không
 *   - HashMap.get(key)         : Lấy giá trị tương ứng với key
 *   - HashMap.put(key, value)  : Thêm hoặc cập nhật cặp key-value
 *   - String.toLowerCase()    : Chuyển chuỗi về chữ thường
 *   - String.replaceAll()     : Xóa ký tự theo regex (bỏ dấu câu)
 *   - String.split()          : Tách chuỗi thành mảng từ
 *   - ArrayList.contains()    : Kiểm tra phần tử có trong danh sách (duyệt tuần tự O(n))
 */
public class WordCounter {

    // --- CÁCH 2: HashMap ---
    private HashMap<String, Integer> wordMap;

    public WordCounter() {
        wordMap = new HashMap<>();
    }

    /**
     * Phương thức analyze(): Chuẩn hóa và đếm tần suất từ.
     * B1: Chuẩn hóa chuỗi
     * B2: Tách thành mảng từ
     * B3: Dùng containsKey để phân nhánh xử lý
     */
    public void analyze(String text) {
        // B1: Chuẩn hóa - chuyển về chữ thường và bỏ dấu chấm, phẩy
        String normalized = text.toLowerCase().replaceAll("[^a-z\\s]", "");

        // B2: Tách thành mảng từng từ
        String[] words = normalized.split("\\s+");

        // B3: Duyệt mảng và đếm
        for (String word : words) {
            if (word.isEmpty()) continue;

            if (wordMap.containsKey(word)) {
                // Từ đã có trong Map -> lấy giá trị cũ + 1 rồi put lại
                int oldCount = wordMap.get(word);
                wordMap.put(word, oldCount + 1);
            } else {
                // Từ chưa có -> put vào Map với giá trị 1
                wordMap.put(word, 1);
            }
        }
    }

    /**
     * Phương thức displayResult(): In ra tất cả từ và số lần xuất hiện.
     * Sau đó tìm và in từ xuất hiện nhiều nhất.
     */
    public void displayResult() {
        System.out.println("=== DANH SACH TU VA SO LAN XUAT HIEN ===");
        for (String word : wordMap.keySet()) {
            System.out.println("  \"" + word + "\" -> " + wordMap.get(word) + " lan");
        }

        // Tìm từ xuất hiện nhiều nhất
        String mostFreqWord = "";
        int maxCount = 0;

        for (String word : wordMap.keySet()) {
            if (wordMap.get(word) > maxCount) {
                maxCount = wordMap.get(word);
                mostFreqWord = word;
            }
        }

        System.out.println("\n=== TU XUAT HIEN NHIEU NHAT ===");
        System.out.println("  \"" + mostFreqWord + "\" -> " + maxCount + " lan");
    }

    /**
     * Phương thức minh họa CÁCH 1 (ArrayList) để so sánh.
     * Đây là cách kém hiệu quả hơn - chỉ mang tính minh họa.
     */
    public static void analyzeWithArrayList(String text) {
        System.out.println("\n=== PHAN TICH BANG ARRAYLIST (minh hoa O(n)) ===");

        String normalized = text.toLowerCase().replaceAll("[^a-z\\s]", "");
        String[] words = normalized.split("\\s+");

        // Dùng 2 ArrayList song song: một lưu từ, một lưu số đếm
        ArrayList<String> wordList  = new ArrayList<>();
        ArrayList<Integer> countList = new ArrayList<>();

        for (String word : words) {
            if (word.isEmpty()) continue;

            // contains() phải duyệt toàn bộ danh sách để tìm -> O(n)
            if (wordList.contains(word)) {
                int index = wordList.indexOf(word);
                countList.set(index, countList.get(index) + 1);
            } else {
                wordList.add(word);
                countList.add(1);
            }
        }

        for (int i = 0; i < wordList.size(); i++) {
            System.out.println("  \"" + wordList.get(i) + "\" -> " + countList.get(i) + " lan");
        }
    }
}
