package bai1.code;
import java.util.*;

public class main {
    public static void useString() {
        ArrayList<String> chuoi = new ArrayList<>();
        for (int i = 0; i<100000;i++) {
            chuoi.add("Hello");
        }
        System.out.println(System.currentTimeMillis());
    }
    public static void useStringBuffer() {
        StringBuffer chuois = new StringBuffer();
        for (int i = 0; i<100000;i++) {
            chuois.append("Hello");
        }
        System.out.println(System.currentTimeMillis());
    }
    public static void contentAnalysis(String s) {
        String[] line = s.split("[.?!]");
        int count = line.length;
        System.out.println(count);

        String b = s.replace("Java","Python");
        System.out.println(b);
        }
    public static void main(String[] args) {
        useString();
        useStringBuffer();
        contentAnalysis("Nguyen Minh Duc Java.Roblox Java?Hum Java!");
    }
}

