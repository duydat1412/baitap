package bai7.code;

import java.io.BufferedReader;    // BufferedReader: Doc tep theo tung dong, hieu qua hon FileReader don thuan
import java.io.FileNotFoundException; // Nem ra khi file nguon khong ton tai
import java.io.FileReader;        // FileReader: Mo file de doc theo ky tu
import java.io.FileWriter;        // FileWriter: Mo file de ghi theo ky tu
import java.io.IOException;       // Lop cha cua cac ngoai le lien quan den I/O
import java.io.PrintWriter;       // PrintWriter: Ghi vao file theo tung dong (co phuong thuc println)
import java.util.Scanner;

/**
 * Bai 7 - Bai 2: Sao chep tep van ban.
 *
 * Thu vien / Ham su dung:
 *
 * FileReader:
 *   - Mo mot file de doc theo kieu ky tu (character stream).
 *   - Nem FileNotFoundException neu file khong ton tai.
 *
 * BufferedReader:
 *   - Boc quanh FileReader de doc theo tung dong bang readLine().
 *   - readLine(): Tra ve mot dong van ban, tra ve null neu het file.
 *
 * FileWriter:
 *   - Mo mot file de ghi theo kieu ky tu.
 *   - Nem IOException neu khong the tao file dich.
 *
 * PrintWriter:
 *   - Boc quanh FileWriter de ghi theo tung dong bang println().
 *
 * Khoi finally:
 *   - Luon chay de dam bao dong file, tranh ro ri tai nguyen.
 *   - Goi close() trong finally la thong le tot.
 */
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhap duong dan tep nguon: ");
        String sourcePath = sc.nextLine().trim();

        System.out.print("Nhap duong dan tep dich: ");
        String destPath = sc.nextLine().trim();

        sc.close();

        BufferedReader reader = null;
        PrintWriter writer = null;
        int lineCount = 0;

        try {
            // Mo file de doc
            reader = new BufferedReader(new FileReader(sourcePath));

            // Mo file de ghi
            writer = new PrintWriter(new FileWriter(destPath));

            String line;
            // readLine() tra ve null khi het file
            while ((line = reader.readLine()) != null) {
                writer.println(line); // Ghi tung dong vao file dich
                lineCount++;
            }

            System.out.println("Sao chep thanh cong! So dong da sao chep: " + lineCount);

        } catch (FileNotFoundException e) {
            // File nguon khong ton tai, hoac khong the tao file dich
            System.out.println("Source file not found.");

        } catch (IOException e) {
            // Loi I/O khac (quyen truy cap, o dia day...)
            System.out.println("I/O error.");
            e.printStackTrace(); // In stack trace de debug

        } finally {
            // Dong file trong finally - luon chay du co loi hay khong
            try {
                if (reader != null) reader.close();
                if (writer != null) writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
