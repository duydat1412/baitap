package bai9.code;

import java.io.EOFException;           // Nem ra khi ObjectInputStream doc toi cuoi file (het doi tuong)
import java.io.FileInputStream;        // Mo file de doc byte
import java.io.FileNotFoundException;  // Nem ra khi file khong ton tai
import java.io.FileOutputStream;       // Mo file de ghi byte
import java.io.IOException;
import java.io.ObjectInputStream;      // Doc doi tuong da duoc serialize tu file
import java.io.ObjectOutputStream;     // Ghi doi tuong (Serializable) vao file
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Bai 9 - Bai 4: Danh sach sinh vien (Serialization).
 *
 * Thu vien / Ham su dung:
 *
 * ObjectOutputStream:
 *   - Ghi toan bo doi tuong Java vao file nhi phan.
 *   - writeObject(obj): Chuyen doi tuong thanh byte va ghi vao file.
 *   - Doi tuong phai implements Serializable.
 *
 * ObjectInputStream:
 *   - Doc lai doi tuong da duoc ghi bang ObjectOutputStream.
 *   - readObject(): Doc mot doi tuong tu file, tra ve kieu Object.
 *   - Phai ep kieu (cast) lai dung kieu: (Student).
 *   - Nem EOFException khi doc het file.
 *   - Nem ClassNotFoundException neu khong tim thay lop tuong ung.
 */
public class main {

    static final String FILE_NAME = "students.dat";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        // ===== NHAP DANH SACH SINH VIEN =====
        System.out.println("Nhap sinh vien (nhap END de ket thuc):");
        while (true) {
            System.out.print("Nhap ID (hoac END): ");
            String id = sc.nextLine().trim();
            if (id.equalsIgnoreCase("END")) break;

            System.out.print("Nhap ten: ");
            String name = sc.nextLine().trim();

            System.out.print("Nhap GPA: ");
            double gpa = Double.parseDouble(sc.nextLine().trim());

            students.add(new Student(id, name, gpa));
        }
        sc.close();

        // ===== GHI DANH SACH RA FILE =====
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME));
            for (Student s : students) {
                oos.writeObject(s); // Ghi tung doi tuong Student vao file
            }
            System.out.println("Ghi file thanh cong: " + FILE_NAME);

        } catch (FileNotFoundException e) {
            System.out.println("Cannot create destination file.");
        } catch (IOException e) {
            System.out.println("I/O error.");
            e.printStackTrace();
        } finally {
            try {
                if (oos != null) oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // ===== DOC LAI TU FILE VA IN =====
        System.out.println("\nDoc lai danh sach sinh vien tu file:");
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(FILE_NAME));
            while (true) {
                try {
                    // readObject() tra ve Object, phai cast sang Student
                    Student s = (Student) ois.readObject();
                    System.out.println("  " + s);
                } catch (EOFException e) {
                    // Het doi tuong trong file -> dung vong lap
                    break;
                } catch (ClassNotFoundException e) {
                    // Khong tim thay lop Student khi giai ma
                    System.out.println("Loi: Khong tim thay class Student.");
                    break;
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("Source file not found.");
        } catch (IOException e) {
            System.out.println("I/O error.");
            e.printStackTrace();
        } finally {
            try {
                if (ois != null) ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
