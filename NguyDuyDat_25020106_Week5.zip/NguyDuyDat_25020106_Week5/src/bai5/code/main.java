package bai5.code;

/**
 * Chuong trinh chinh: Mo phong he thong quan ly thu vien voi 3 cau truc du lieu.
 *
 * Ket luan phan tich do phuc tap:
 *
 * | Thao tac  | ArrayList | HashMap | TreeMap  |
 * |-----------|-----------|---------|----------|
 * | Them      | O(1)      | O(1)    | O(log n) |
 * | Tim kiem  | O(n)      | O(1)    | O(log n) |
 * | Xoa       | O(n)      | O(1)    | O(log n) |
 * | Sap xep   | Can sort  | Khong   | Tu dong  |
 *
 * Nen dung cau truc nao?
 *   - So sach nho              -> ArrayList (don gian, de dung)
 *   - So sach rat lon          -> HashMap   (tim kiem/xoa O(1))
 *   - Can du lieu sap xep theo id -> TreeMap (tu dong sap xep)
 */
public class main {
    public static void main(String[] args) {

        // Tao 5 cuon sach mau
        Book b1 = new Book("B003", "Clean Code",              "Robert C. Martin", 2008);
        Book b2 = new Book("B001", "The Pragmatic Programmer","Andrew Hunt",      1999);
        Book b3 = new Book("B005", "Design Patterns",         "Gang of Four",     1994);
        Book b4 = new Book("B002", "Effective Java",          "Joshua Bloch",     2018);
        Book b5 = new Book("B004", "Head First Java",         "Kathy Sierra",     2005);

        // ============================================================
        // 1. ARRAYLIST LIBRARY
        // ============================================================
        System.out.println("========== ARRAYLIST ==========");
        ArrayListLibrary arrayLib = new ArrayListLibrary();
        arrayLib.add(b1);
        arrayLib.add(b2);
        arrayLib.add(b3);
        arrayLib.add(b4);
        arrayLib.add(b5);

        System.out.println();
        arrayLib.printAll();

        System.out.println();
        Book found = arrayLib.findById("B002");
        System.out.println("[ArrayList] Tim B002: " + (found != null ? found : "Khong tim thay"));

        System.out.println();
        arrayLib.deleteById("B003");
        arrayLib.printAll();

        // ============================================================
        // 2. HASHMAP LIBRARY
        // ============================================================
        System.out.println("\n========== HASHMAP ==========");
        HashMapLibrary hashLib = new HashMapLibrary();
        hashLib.add(b1);
        hashLib.add(b2);
        hashLib.add(b3);
        hashLib.add(b4);
        hashLib.add(b5);

        System.out.println();
        hashLib.printAll();

        System.out.println();
        found = hashLib.findById("B004");
        System.out.println("[HashMap] Tim B004: " + (found != null ? found : "Khong tim thay"));

        System.out.println();
        hashLib.deleteById("B001");
        hashLib.printAll();

        // ============================================================
        // 3. TREEMAP LIBRARY
        // ============================================================
        System.out.println("\n========== TREEMAP ==========");
        TreeMapLibrary treeLib = new TreeMapLibrary();
        treeLib.add(b1);
        treeLib.add(b2);
        treeLib.add(b3);
        treeLib.add(b4);
        treeLib.add(b5);

        System.out.println();
        // TreeMap tu dong sap xep theo id -> in ra thu tu B001, B002, B003, B004, B005
        treeLib.printAll();

        System.out.println();
        found = treeLib.findById("B005");
        System.out.println("[TreeMap] Tim B005: " + (found != null ? found : "Khong tim thay"));

        System.out.println();
        treeLib.deleteById("B002");
        treeLib.printAll();

        // ============================================================
        // Tong ket do phuc tap
        // ============================================================
        System.out.println("\n========== SO SANH DO PHUC TAP (Big-O) ==========");
        System.out.println("Thao tac  | ArrayList | HashMap | TreeMap");
        System.out.println("----------|-----------|---------|--------");
        System.out.println("Them      |   O(1)    |  O(1)   | O(log n)");
        System.out.println("Tim kiem  |   O(n)    |  O(1)   | O(log n)");
        System.out.println("Xoa       |   O(n)    |  O(1)   | O(log n)");
        System.out.println("Sap xep   | Can sort  |  Khong  | Tu dong");
        System.out.println();
        System.out.println("=> Sach nhieu, tim nhieu -> dung HashMap");
        System.out.println("=> Can sap xep theo id   -> dung TreeMap");
        System.out.println("=> Sach it, don gian     -> dung ArrayList");
    }
}
