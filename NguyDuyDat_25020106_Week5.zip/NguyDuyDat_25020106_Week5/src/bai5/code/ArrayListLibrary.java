package bai5.code;

import java.util.ArrayList;

/**
 * Quan ly thu vien bang ArrayList.
 *
 * Do phuc tap (Big-O):
 *   - Them sach  (add)    : O(1) - them vao cuoi danh sach, nhanh.
 *   - Tim sach   (findById): O(n) - phai duyet tung phan tu de kiem tra id, cham.
 *   - Xoa sach   (deleteById): O(n) - phai tim vi tri truoc roi moi xoa, cham.
 *   - In danh sach (printAll): O(n) - duyet het danh sach.
 *
 * Phu hop khi: So luong sach nho, khong can tim kiem nhieu.
 *
 * Thu vien/Ham su dung:
 *   - ArrayList<Book>    : Danh sach dong, luu cac doi tuong Book.
 *   - add(item)          : Them phan tu vao cuoi danh sach.
 *   - remove(index)      : Xoa phan tu tai vi tri chi dinh.
 *   - get(index)         : Lay phan tu tai vi tri chi dinh.
 *   - size()             : Lay so luong phan tu.
 */
public class ArrayListLibrary {

    private ArrayList<Book> books;

    public ArrayListLibrary() {
        books = new ArrayList<>();
    }

    // Them sach - O(1)
    public void add(Book book) {
        books.add(book);
        System.out.println("[ArrayList] Da them: " + book);
    }

    // Tim sach theo id - O(n): phai duyet tung phan tu
    public Book findById(String id) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId().equals(id)) {
                return books.get(i);
            }
        }
        return null;
    }

    // Xoa sach theo id - O(n): phai tim vi tri truoc
    public void deleteById(String id) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId().equals(id)) {
                books.remove(i);
                System.out.println("[ArrayList] Da xoa sach id: " + id);
                return;
            }
        }
        System.out.println("[ArrayList] Khong tim thay sach id: " + id);
    }

    // In danh sach sach - O(n)
    public void printAll() {
        System.out.println("[ArrayList] Danh sach sach (" + books.size() + " quyen):");
        for (Book b : books) {
            System.out.println("  " + b);
        }
    }
}
