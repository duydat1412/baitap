package bai5.code;

import java.util.HashMap;

/**
 * Quan ly thu vien bang HashMap<String, Book>.
 *   Key   = id sach (String)
 *   Value = doi tuong Book
 *
 * Do phuc tap (Big-O):
 *   - Them sach  (add)         : O(1) - tra bang bam, them rat nhanh.
 *   - Tim sach   (findById)    : O(1) - lay truc tiep qua key, nhanh nhat.
 *   - Xoa sach   (deleteById)  : O(1) - xoa truc tiep qua key.
 *   - In danh sach (printAll)  : O(n) - van phai duyet het.
 *
 * Tai sao HashMap nhanh hon ArrayList khi tim kiem?
 *   ArrayList phai duyet tung phan tu tu dau den cuoi (O(n)).
 *   HashMap dung ham bam (hash function) chuyen id thanh vi tri trong bang,
 *   nen co the truy cap truc tiep ma khong can duyet -> O(1).
 *
 * Phu hop khi: So luong sach lon, can tim/xoa thuong xuyen.
 *
 * Thu vien/Ham su dung:
 *   - HashMap<String, Book>  : Luu cap key-value (id -> Book).
 *   - put(key, value)        : Them hoac cap nhat sach.
 *   - get(key)               : Lay Book tuong ung voi id.
 *   - remove(key)            : Xoa cap key-value.
 *   - containsKey(key)       : Kiem tra id co ton tai trong Map khong.
 *   - values()               : Lay tat ca cac value (Book) de duyet.
 */
public class HashMapLibrary {

    private HashMap<String, Book> books;

    public HashMapLibrary() {
        books = new HashMap<>();
    }

    // Them sach - O(1)
    public void add(Book book) {
        books.put(book.getId(), book);
        System.out.println("[HashMap] Da them: " + book);
    }

    // Tim sach theo id - O(1)
    public Book findById(String id) {
        return books.get(id); // Tra ve null neu khong tim thay
    }

    // Xoa sach theo id - O(1)
    public void deleteById(String id) {
        if (books.containsKey(id)) {
            books.remove(id);
            System.out.println("[HashMap] Da xoa sach id: " + id);
        } else {
            System.out.println("[HashMap] Khong tim thay sach id: " + id);
        }
    }

    // In danh sach sach - O(n)
    public void printAll() {
        System.out.println("[HashMap] Danh sach sach (" + books.size() + " quyen):");
        for (Book b : books.values()) {
            System.out.println("  " + b);
        }
    }
}
