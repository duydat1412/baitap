package bai5.code;

import java.util.TreeMap;

/**
 * Quan ly thu vien bang TreeMap<String, Book>.
 *   Key   = id sach (String)
 *   Value = doi tuong Book
 *
 * Do phuc tap (Big-O):
 *   - Them sach  (add)         : O(log n) - duy tri cay nhi phan tim kiem can bang (Red-Black Tree).
 *   - Tim sach   (findById)    : O(log n) - tim kiem nhi phan tren cay.
 *   - Xoa sach   (deleteById)  : O(log n) - xoa tren cay.
 *   - In danh sach (printAll)  : O(n) - duyet het.
 *
 * Diem khac biet lon nhat so voi HashMap:
 *   TreeMap tu dong sap xep cac key (id) theo thu tu tang dan.
 *   -> Khi in danh sach, sach luon duoc sap xep theo id ma khong can sort them.
 *
 * Phu hop khi: Can du lieu duoc sap xep theo id, so sach vua phai.
 *
 * Thu vien/Ham su dung:
 *   - TreeMap<String, Book>  : Luu cap key-value, tu dong sap xep theo key.
 *   - put(key, value)        : Them sach (va tu dong sap xep lai).
 *   - get(key)               : Lay Book theo id.
 *   - remove(key)            : Xoa sach.
 *   - containsKey(key)       : Kiem tra id ton tai.
 *   - values()               : Lay tat ca Book da duoc sap xep.
 */
public class TreeMapLibrary {

    private TreeMap<String, Book> books;

    public TreeMapLibrary() {
        books = new TreeMap<>();
    }

    // Them sach - O(log n), tu dong sap xep theo id
    public void add(Book book) {
        books.put(book.getId(), book);
        System.out.println("[TreeMap] Da them: " + book);
    }

    // Tim sach theo id - O(log n)
    public Book findById(String id) {
        return books.get(id);
    }

    // Xoa sach theo id - O(log n)
    public void deleteById(String id) {
        if (books.containsKey(id)) {
            books.remove(id);
            System.out.println("[TreeMap] Da xoa sach id: " + id);
        } else {
            System.out.println("[TreeMap] Khong tim thay sach id: " + id);
        }
    }

    // In danh sach sach - O(n), sach da duoc sap xep theo id
    public void printAll() {
        System.out.println("[TreeMap] Danh sach sach (sap xep theo id, " + books.size() + " quyen):");
        for (Book b : books.values()) {
            System.out.println("  " + b);
        }
    }
}
