package bai10.code;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Bai 10 - Bai 5: Doc cau hinh + kiem tra du lieu (Custom Exception).
 *
 * Thu vien / Ham su dung:
 *
 * FileReader + BufferedReader:
 *   - Doc file cau hinh theo tung dong.
 *   - readLine(): Tra ve tung dong, null khi het file.
 *
 * String.split("=", 2):
 *   - Tach dong "key=value" thanh mang 2 phan tu: [key, value].
 *   - Tham so 2 gioi han chi tach toi da 1 lan (tranh tach sai neu value co dau =).
 *
 * Map<String, String>:
 *   - Luu cac cap cau hinh: key -> value.
 *   - containsKey(key): Kiem tra key co ton tai khong.
 *   - get(key): Lay value theo key.
 *
 * NumberFormatException:
 *   - Nem ra boi Integer.parseInt() khi chuoi khong phai so nguyen hop le.
 *
 * InvalidConfigException (Custom Exception):
 *   - Nem ra khi thieu truong bat buoc hoac gia tri sai quy tac.
 *   - Khi nem: throw new InvalidConfigException("thong bao").
 *   - Khi bat: catch (InvalidConfigException e).
 */
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap duong dan file config: ");
        String filePath = sc.nextLine().trim();
        sc.close();

        Map<String, String> config = new HashMap<>();
        BufferedReader reader = null;

        try {
            // Doc file cau hinh
            reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                // Bo qua dong trong va dong comment bat dau bang #
                if (line.isEmpty() || line.startsWith("#")) continue;

                // Tach theo dau = (gioi han 2 phan de tranh loi neu value co dau =)
                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    config.put(parts[0].trim(), parts[1].trim());
                }
            }

            // Kiem tra du lieu cau hinh
            validateConfig(config);

            // In toan bo cau hinh
            System.out.println("Config loaded successfully.");
            System.out.println("Cau hinh da doc:");
            for (String key : config.keySet()) {
                System.out.println("  " + key + " = " + config.get(key));
            }

        } catch (FileNotFoundException e) {
            System.out.println("Config file not found.");

        } catch (IOException e) {
            System.out.println("I/O error.");
            e.printStackTrace();

        } catch (NumberFormatException e) {
            System.out.println("Invalid number format.");

        } catch (InvalidConfigException e) {
            System.out.println("Invalid config: " + e.getMessage());

        } finally {
            // Dong file trong finally - luon chay
            try {
                if (reader != null) reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("Program finished.");
        }
    }

    /**
     * Kiem tra tinh hop le cua cau hinh.
     * Nem InvalidConfigException neu sai quy tac.
     * Nem NumberFormatException neu gia tri khong dung so.
     */
    static void validateConfig(Map<String, String> config)
            throws InvalidConfigException, NumberFormatException {

        // Bat buoc phai co username
        if (!config.containsKey("username")) {
            throw new InvalidConfigException("Missing required field: username");
        }

        // Bat buoc phai co timeout va phai la so nguyen > 0
        if (!config.containsKey("timeout")) {
            throw new InvalidConfigException("Missing required field: timeout");
        }
        int timeout = Integer.parseInt(config.get("timeout")); // Nem NumberFormatException neu sai
        if (timeout <= 0) {
            throw new InvalidConfigException("timeout must be > 0");
        }

        // Neu co maxConnections thi phai la so nguyen >= 1
        if (config.containsKey("maxConnections")) {
            int maxConn = Integer.parseInt(config.get("maxConnections")); // Nem NumberFormatException neu sai
            if (maxConn < 1) {
                throw new InvalidConfigException("maxConnections must be >= 1");
            }
        }
    }
}
