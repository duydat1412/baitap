package bai10.code;

/**
 * Custom Exception: Nem ra khi cau hinh khong hop le.
 *
 * Custom Exception (Ngoai le tu dinh nghia):
 *   - Tao bang cach ke thua lop Exception.
 *   - Cho phep dinh nghia loi dac thu cho ung dung.
 *   - Goi: throw new InvalidConfigException("thong bao") de nem ra.
 */
public class InvalidConfigException extends Exception {
    public InvalidConfigException(String message) {
        super(message); // Truyen thong bao len lop cha Exception
    }
}
