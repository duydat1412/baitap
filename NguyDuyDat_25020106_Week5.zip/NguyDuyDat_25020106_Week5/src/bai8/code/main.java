package bai8.code;

import java.io.DataInputStream;   // DataInputStream: Doc du lieu kieu nguyen thuy (int, double...) tu file nhi phan
import java.io.DataOutputStream;  // DataOutputStream: Ghi du lieu kieu nguyen thuy vao file nhi phan
import java.io.EOFException;      // Nem ra khi doc toi cuoi file nhi phan (het du lieu)
import java.io.FileInputStream;   // FileInputStream: Mo file de doc byte
import java.io.FileOutputStream;  // FileOutputStream: Mo file de ghi byte
import java.io.IOException;
import java.util.Scanner;

/**
 * Bai 8 - Bai 3: Doc va ghi du lieu nhi phan.
 *
 * Thu vien / Ham su dung:
 *
 * DataOutputStream:
 *   - Ghi du lieu kieu nguyen thuy vao file nhi phan.
 *   - writeInt(int): Ghi mot so nguyen 4 byte vao file.
 *   - Boc quanh FileOutputStream de luu ra file.
 *
 * DataInputStream:
 *   - Doc du lieu kieu nguyen thuy tu file nhi phan.
 *   - readInt(): Doc 4 byte tu file va tra ve gia tri int tuong ung.
 *   - Khi het file, readInt() nem ra EOFException.
 *
 * EOFException:
 *   - La dau hieu file da doc het, dung de ket thuc vong lap doc.
 *   - EOFException la con cua IOException.
 *
 * File nhi phan (binary file) khac file van ban:
 *   - Luu so nguyen 100 chi ton 4 byte (kieu int).
 *   - File van ban luu "100" ton 3 byte (3 ky tu ASCII).
 *   - File nhi phan nho hon va doc/ghi nhanh hon.
 */
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhap ten file (vi du: numbers.dat): ");
        String fileName = sc.nextLine().trim();

        // ===== CHUONG TRINH 1: GHI DU LIEU =====
        System.out.print("Nhap so luong so nguyen muon ghi: ");
        int n = sc.nextInt();

        DataOutputStream dos = null;
        try {
            dos = new DataOutputStream(new FileOutputStream(fileName));

            System.out.println("Nhap " + n + " so nguyen:");
            for (int i = 0; i < n; i++) {
                System.out.print("  So thu " + (i + 1) + ": ");
                int num = sc.nextInt();
                dos.writeInt(num); // Ghi so nguyen 4 byte vao file nhi phan
            }
            System.out.println("Ghi file thanh cong: " + fileName);

        } catch (IOException e) {
            System.out.println("I/O error khi ghi file.");
            e.printStackTrace();

        } finally {
            try {
                if (dos != null) dos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // ===== CHUONG TRINH 2: DOC DU LIEU =====
        System.out.println("\nDoc lai du lieu tu file: " + fileName);

        DataInputStream dis = null;
        try {
            dis = new DataInputStream(new FileInputStream(fileName));

            System.out.print("Cac so da ghi: ");
            while (true) {
                try {
                    int num = dis.readInt(); // Nem EOFException khi het file
                    System.out.print(num + " ");
                } catch (EOFException e) {
                    // Bat EOFException de dung vong lap khi het du lieu
                    break;
                }
            }
            System.out.println("\nDoc file thanh cong.");

        } catch (IOException e) {
            System.out.println("I/O error khi doc file.");
            e.printStackTrace();

        } finally {
            try {
                if (dis != null) dis.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        sc.close();
    }
}
