package bai3.code;

/**
 * Lớp main: Mô phỏng phân tích tần suất từ trên một đoạn văn bản tiếng Anh (~1 trang A4).
 *
 * Quy trình:
 *   1. Chuẩn bị một đoạn văn bản dài (~300-400 từ)
 *   2. Tạo WordFrequencyCounter và chạy countWords()
 *   3. In kết quả thống kê qua printStats()
 *
 * Lưu ý: Dùng String thông thường (tương thích Java 8+) thay vì Text Block (Java 15+)
 */
public class main {
    public static void main(String[] args) {

        // Đoạn văn bản tiếng Anh dài (~1 trang A4) để phân tích
        // Dùng + để nối chuỗi, tương thích với mọi phiên bản Java
        String text =
                "Education is one of the most powerful tools available to individuals and societies. " +
                "Through education, people gain the knowledge, skills, and critical thinking abilities " +
                "they need to navigate the complexities of modern life. Education empowers individuals " +
                "to make informed decisions, pursue meaningful careers, and contribute positively " +
                "to their communities and the world at large. " +

                "The importance of education extends beyond personal development. A well-educated " +
                "population drives economic growth, fosters innovation, and promotes social stability. " +
                "Countries that invest heavily in education tend to have higher standards of living, " +
                "lower rates of unemployment, and stronger democratic institutions. Education also " +
                "plays a crucial role in reducing poverty and inequality, providing individuals with " +
                "the means to improve their circumstances regardless of their background. " +

                "In the modern era, access to education has been transformed by technology. " +
                "The internet and digital tools have made learning more accessible than ever before. " +
                "Online courses, educational platforms, and open resources allow people from all " +
                "corners of the world to access high-quality education at little or no cost. " +
                "This democratization of education is helping to close the gap between the privileged " +
                "and the underprivileged, offering new opportunities to those who were previously " +
                "excluded from quality learning experiences. " +

                "However, challenges remain. Many children around the world still lack access to " +
                "basic education due to poverty, conflict, or discrimination. Girls in particular " +
                "face significant barriers to education in many regions. Addressing these challenges " +
                "requires concerted effort from governments, international organizations, and civil " +
                "society. Quality education must be recognized as a fundamental human right, not " +
                "a privilege reserved for the few. " +

                "Furthermore, the content and methods of education must evolve to meet the demands " +
                "of a rapidly changing world. Critical thinking, creativity, collaboration, and " +
                "communication are increasingly important in an era of automation and artificial intelligence. " +
                "Schools and universities must adapt their curricula to prepare students not just " +
                "for today's job market, but for the unpredictable challenges of the future. " +

                "In conclusion, education remains the cornerstone of human progress and social " +
                "development. Investing in education is investing in the future. As Nelson Mandela " +
                "once said, education is the most powerful weapon which you can use to change " +
                "the world. Ensuring every child has access to quality education is both a moral " +
                "imperative and a practical necessity for building a just and prosperous society.";

        // Tạo đối tượng WordFrequencyCounter
        WordFrequencyCounter counter = new WordFrequencyCounter();

        // Bước 1: Đếm tần suất từ
        counter.countWords(text);

        // Bước 2a: In từ xuất hiện nhiều nhất
        counter.printMostFrequent();

        // Bước 2b: In danh sách unique words
        counter.printUniqueWords();
    }
}
