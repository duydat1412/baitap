package bai3.code;

import java.util.ArrayList;   // ArrayList: Danh sách động để lưu các từ unique
import java.util.Collections; // Collections: Cung cấp hàm sort() để sắp xếp danh sách
import java.util.HashMap;     // HashMap: Lưu cặp (từ -> số lần xuất hiện) dạng key-value
import java.util.Map;         // Map: Interface cha của HashMap, dùng khi duyệt entrySet()

/**
 * Lớp WordFrequencyCounter: Đếm tần suất từ trong một đoạn văn bản.
 *
 * Các thư viện và hàm built-in sử dụng:
 *
 * HashMap<String, Integer>:
 *   - put(key, value)          : Thêm hoặc cập nhật cặp key-value vào Map
 *   - getOrDefault(key, def)   : Lấy giá trị của key, nếu không có thì trả về giá trị mặc định
 *   - entrySet()               : Trả về tập hợp tất cả cặp key-value để duyệt vòng lặp
 *
 * String methods:
 *   - toLowerCase()            : Chuyển toàn bộ chuỗi về chữ thường ("The" -> "the")
 *   - replaceAll(regex, str)   : Xóa các ký tự khớp với regex (dùng để bỏ dấu câu)
 *   - split(regex)             : Tách chuỗi thành mảng theo ký tự phân cách
 *   - isEmpty()                : Kiểm tra chuỗi có rỗng không
 *
 * Collections.sort():
 *   - Sắp xếp danh sách theo thứ tự bảng chữ cái
 */
public class WordFrequencyCounter {

    // HashMap lưu tần suất từ: key = từ, value = số lần xuất hiện
    private HashMap<String, Integer> frequencyMap;

    public WordFrequencyCounter() {
        this.frequencyMap = new HashMap<>();
    }

    // Bước 1 - CHUẨN HÓA: Chuyển về chữ thường và bỏ dấu câu
    private String normalize(String text) {
        // toLowerCase(): Chuyển "Education" và "education" về cùng dạng "education"
        String lower = text.toLowerCase();

        // replaceAll("[^a-z\\s]", ""): Xóa mọi ký tự không phải chữ cái hoặc khoảng trắng
        // [^a-z\s] = KHÔNG phải chữ a-z và KHÔNG phải khoảng trắng -> xóa dấu phẩy, chấm, v.v.
        return lower.replaceAll("[^a-z\\s]", "");
    }

    // Bước 2 - ĐẾM TỪ: Sử dụng HashMap để đếm số lần xuất hiện của từng từ
    public void countWords(String text) {
        String normalized = normalize(text);

        // split("\\s+"): Tách chuỗi theo khoảng trắng (1 hoặc nhiều)
        String[] words = normalized.split("\\s+");

        for (String word : words) {
            if (word.isEmpty()) continue;

            // Nếu từ chưa có trong Map -> getOrDefault trả về 0, cộng 1 -> put vào Map với count = 1
            // Nếu từ đã có -> lấy count cũ, cộng 1 -> cập nhật lại
            frequencyMap.put(word, frequencyMap.getOrDefault(word, 0) + 1);
        }
    }

    // Bước 3a - Tìm từ xuất hiện nhiều nhất
    public void printMostFrequent() {
        String mostFreqWord = "";
        int maxCount = 0;

        // Duyệt qua tất cả cặp key-value để tìm count lớn nhất
        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                mostFreqWord = entry.getKey();
            }
        }

        System.out.println("Tu xuat hien nhieu nhat: \"" + mostFreqWord + "\" (" + maxCount + " lan)");
    }

    // Bước 3b - Liệt kê các từ chỉ xuất hiện đúng 1 lần (Unique words)
    public void printUniqueWords() {
        ArrayList<String> uniqueWords = new ArrayList<>();

        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() == 1) {
                uniqueWords.add(entry.getKey());
            }
        }

        // Collections.sort(): Sắp xếp theo thứ tự bảng chữ cái cho dễ đọc
        Collections.sort(uniqueWords);

        System.out.println("Tong so tu phan biet: " + frequencyMap.size());
        System.out.println("So unique words (chi xuat hien 1 lan): " + uniqueWords.size());
        System.out.println("Danh sach: " + uniqueWords);
    }
}
