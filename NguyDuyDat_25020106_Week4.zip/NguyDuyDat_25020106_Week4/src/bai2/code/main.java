package bai2.code;

public class main {
    public static void main(String[] args) {
        Hero hero = new Hero();
        // 1. Ép kiểu về CanSwim để gọi hàm swim()
        CanSwim swimmer = (CanSwim) hero;
        swimmer.swim();

        // 2. Ép kiểu về CanFight để gọi hàm fight()
        CanFight fighter = (CanFight) hero;
        fighter.fight();
    }
}
