package bai2.code;

public class Hero extends ActionCharacter implements CanFly,CanSwim,CanFight{
    public void fly() {
        System.out.println("Hero is flying");
    }
    public void swim() {
        System.out.println("Hero is swimming");
    }
//    public void fight() {
//        System.out.println("Hero is fighting");
//    }

    //Vì ActionCharacter đã có hàm fight(), lớp Hero ko cần implement lại fight() của CanFight
}
