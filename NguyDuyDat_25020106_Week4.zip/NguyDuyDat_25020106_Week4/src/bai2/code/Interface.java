package bai2.code;

interface CanFly {
    void fly();
}
interface CanSwim {
    void swim();
}
interface CanFight{
    void fight();
}
