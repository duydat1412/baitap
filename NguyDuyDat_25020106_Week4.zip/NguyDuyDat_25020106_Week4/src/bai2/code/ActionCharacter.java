package bai2.code;

public class ActionCharacter implements CanFight {
    public void fight() {
        System.out.println("Đấm bốc...");
    }
}
