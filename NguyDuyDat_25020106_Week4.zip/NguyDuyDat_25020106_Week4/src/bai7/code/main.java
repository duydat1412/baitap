package bai7.code;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<>();
        int n = Integer.parseInt(sc.nextLine());

        for (int i =0;i<n;i++) {
            System.out.println("Nhập thông tin sinh viên : ");
            String[] line = sc.nextLine().trim().split("\\s+");

            int id = Integer.parseInt(line[0]);
            String name = line[1];
            double gpa = Double.parseDouble(line[2]);
            students.add(new Student(id,name,gpa));
        }
        students.removeIf(s -> s.getGpa() < 5.0); // (lambda)
        System.out.println("Sau khi xóa : ");
        students.forEach(s -> System.out.println(s));

        students.sort((s1, s2) -> s1.getName().compareTo(s2.getName()));
        System.out.println("Sau khi sắp xếp theo tên : ");
        students.forEach(s -> System.out.println(s));

        System.out.println("Tính toán :");
        Operation<Double> add = (a, b) -> a + b;
        Operation<Double> sub = (a, b) -> a - b;
        Operation<Double> mul = (a, b) -> a * b;
        Operation<Double> div = (a, b) -> a / b;

        System.out.println("Sum of 7.5 and 8.0: " + add.execute(7.5, 8.0));
        System.out.println("Product of 5.0 and 2.0: " + mul.execute(5.0, 2.0))
    }
}