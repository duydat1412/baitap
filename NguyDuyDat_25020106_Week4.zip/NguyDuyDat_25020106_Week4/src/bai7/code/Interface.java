package bai7.code;

interface Operation<T> {
    T execute(T a, T b);
}
