package bai7.code;

public class Student implements Comparable<bai6.code.Student> {
    public String name;
    public int ID;
    public double gpa;

    public Student(int ID,String name,double gpa) {
        this.name = name;
        this.ID = ID;
        this.gpa=gpa;
    }
    public int getId() { return ID; }
    public String getName() { return name; }
    public double getGpa() { return gpa; }

    @Override
    public int compareTo(bai6.code.Student other) {
        return Double.compare(this.ID, other.ID);
    }
    @Override
    public String toString () {
        return ID + " " + name + " " + gpa;
    }
}

