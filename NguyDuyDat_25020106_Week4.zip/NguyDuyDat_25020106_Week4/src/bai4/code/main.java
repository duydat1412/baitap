package bai4.code;

interface IData {
    void show(); // Mặc định là public abstract
}
class DataManager implements IData {
    // Cố tình KHÔNG ghi public
    public void show() { //viết void show() mà không có từ khóa nào phía trước, Java sẽ hiểu đây là phạm vi default (package-private).
                  //Phạm vi default hẹp hơn (yếu hơn) so với public
                  //Java quy định rằng khi override, lớp con phải giữ nguyên hoặc mở rộng phạm vi truy cập, chứ không được phép thu hẹp lại.
        System.out.println("Show Data");
    }
}
public class main{
    public static void main(String[] args) {
        DataManager d = new DataManager();
        d.show();
    }
}