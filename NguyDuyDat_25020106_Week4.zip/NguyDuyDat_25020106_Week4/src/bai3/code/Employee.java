package bai3.code;

public abstract class Employee implements IWorkable{
    public String Id,name;
    public double baseSalary;

    public Employee(String id, String name, double baseSalary) {
        this.Id=id;
        this.name=name;
        this.baseSalary=baseSalary;
    }
    public abstract void show();

    //Class Employee không bắt buộc phải implement hàm work() của interface vì là abstract class, mà abstract class không trực tiếp tạo ra đối tượng như class thường
}
