package bai3.code;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nhập số lượng nhân viên cần tạo : ");
        int n = Integer.parseInt(sc.nextLine().trim());

        Employee[] employees = new Employee[n];

        for (int i = 0;i<n;i++) {
            System.out.println("Nhập thông tin nhân viên : ");
            String[] line = sc.nextLine().trim().split("\\s+");

            String type = line[0];
            if (type.equals("O")) {
                String Id = line[1];
                String name = line[2];
                double baseSalary = Double.parseDouble(line[3]);
                employees[i] = new OfficeWorker(Id,name,baseSalary);
            }else {
                String Id = line[1];
                String name = line[2];
                double baseSalary = Double.parseDouble(line[3]);
                double overtimeHours = Double.parseDouble(line[4]);
                employees[i] = new Technician(Id,name,baseSalary,overtimeHours);
            }
        }
        for (Employee e : employees) {
            e.show();
            e.work();
        }
    }
}
