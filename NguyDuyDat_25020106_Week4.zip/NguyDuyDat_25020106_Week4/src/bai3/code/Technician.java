package bai3.code;

public class Technician extends Employee{
    public double overtimeHours;

    public Technician(String id,String name,double baseSalary, double overtimeHours) {
        super(id,name,baseSalary);
        this.overtimeHours=overtimeHours;
    }
    public double calculatePay() {
        return baseSalary + overtimeHours*20000;
    }
    public void work() {
        System.out.println("Lắp đặt thiết bị");
    }
    @Override
    public void show() {
        System.out.println(name + " - Pay: " + calculatePay());
    }
}
