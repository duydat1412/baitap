package bai3.code;

public class OfficeWorker extends Employee {
    public OfficeWorker(String id, String name, double baseSalary) {
       super(id,name,baseSalary);
    }

    public double calculatePay() {
        return baseSalary;
    }
    public void work() {
        System.out.println("Soạn thảo văn bản");
    }

    @Override
    public void show() {
        System.out.println(name + " - Pay: " + calculatePay());
    }
}
