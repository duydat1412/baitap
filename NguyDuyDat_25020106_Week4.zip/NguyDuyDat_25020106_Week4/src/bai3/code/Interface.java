package bai3.code;

interface IWorkable {
    void work();
}
