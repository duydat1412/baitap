package bai6.code;

public class main {
    public static void main(String[] args) {
        Integer[] numbers = {5,1,3,2};
        String[] language = {"Java","C++","Pỵthon"};
        Student[] students = {
                new Student("A",1),
                new Student("B",2),
                new Student("C",3)
        };
        ArrayUtils.sort(numbers);
        ArrayUtils.sort(language);
        ArrayUtils.sort(students);

        for (Integer n : numbers) {
            System.out.print(n + " ");
        }
        System.out.println();
        System.out.println();
        for (String s : language)
            System.out.println(s + " ");
        System.out.println();
        for (Student stu : students) {
            System.out.println(stu + " ");
        }
        System.out.println();
    }
}
