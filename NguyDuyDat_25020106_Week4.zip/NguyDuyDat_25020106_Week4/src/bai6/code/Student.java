package bai6.code;

public class Student implements Comparable<Student> {
    public String name;
    public int ID;

    public Student(String name, int ID) {
        this.name = name;
        this.ID = ID;
    }

    @Override
    public int compareTo(Student other) {
        return Double.compare(this.ID, other.ID);
    }
    @Override
    public String toString () {
        return name + " (" + ID + ")";
    }
}
