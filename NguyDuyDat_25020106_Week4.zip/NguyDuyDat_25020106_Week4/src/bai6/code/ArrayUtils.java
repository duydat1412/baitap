package bai6.code;

public class ArrayUtils {
    public static <T> void swap(T[] array,int i,int j) { //T ở đây là kiểu đối tượng, không phải kiểu dữ liệu nguyên thủy
        T temp = array[i];
        array[i]=array[j];
        array[j]=temp;
    }
    public static <T extends Comparable<T>> void sort(T[] array) { //T(Type) bắt buộc phải là một lớp đã implement interface Comparable(java built-in)
        int n = array.length;
        for (int i =0;i<n-1;i++) {
            for (int j = 0;j<n-i-1;j++) {
                if (array[j].compareTo(array[j+1])>0) {  //hàm compareTo thuộc interface Comparable
                    swap(array,j,j+1);
                }
            }
        }
    }
}
