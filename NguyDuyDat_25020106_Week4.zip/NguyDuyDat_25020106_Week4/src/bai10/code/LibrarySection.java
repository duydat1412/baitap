package bai10.code;

import java.util.ArrayList;
import java.util.List;

/**
 * Lớp đại diện cho một khu vực trong thư viện (LibrarySection).
 * Sử dụng Generics với Bounded Type <T extends MediaItem>.
 */
public class LibrarySection<T extends MediaItem> {
    private List<T> items; // Danh sách tài liệu trong khu vực

    public LibrarySection() {
        this.items = new ArrayList<>();
    }

    /**
     * Thêm tài liệu mới vào khu vực.
     */
    public void addItem(T item) {
        items.add(item);
    }

    /**
     * Xóa tài liệu khỏi khu vực theo mã ID.
     */
    public void removeItem(String id) {
        items.removeIf(item -> item.getId().equals(id));
    }

    /**
     * Hiển thị danh sách các tài liệu hiện có trong khu vực.
     */
    public void displayItems() {
        for (T item : items) {
            System.out.println(item.getDisplayInfo());
        }
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
