package bai10.code;

/**
 * Lớp trừu tượng đại diện cho một tài liệu truyền thông trong thư viện.
 */
public abstract class MediaItem {
    protected String id;   // Mã tài liệu
    protected String name; // Tên tài liệu

    public MediaItem(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    /**
     * Phương thức trừu tượng để lấy thông tin hiển thị định dạng chuẩn.
     */
    public abstract String getDisplayInfo();
}
