package bai10.code;

/**
 * Lớp đại diện cho tài liệu Đĩa DVD.
 */
public class DVD extends MediaItem {
    private String director; // Đạo diễn
    private int duration;   // Thời lượng (phút)

    public DVD(String id, String name, String director, int duration) {
        super(id, name);
        this.director = director;
        this.duration = duration;
    }

    @Override
    public String getDisplayInfo() {
        // Định dạng: Tên đĩa - Đạo diễn - Thời lượng (phút)
        return name + " - " + director + " - " + duration;
    }
}
