package bai10.code;

import java.util.Scanner;

/**
 * Lớp chính để chạy hệ thống quản lý thư viện đa phương tiện.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Khởi tạo các khu vực thư viện riêng biệt cho từng loại tài liệu
        LibrarySection<Book> bookSection = new LibrarySection<>();
        LibrarySection<DVD> dvdSection = new LibrarySection<>();

        if (!scanner.hasNextInt()) {
            scanner.close();
            return;
        }
        int n = scanner.nextInt(); // Số lượng tài liệu nhập vào

        for (int i = 0; i < n; i++) {
            String type = scanner.next(); // Loại: 'B' (Sách), 'D' (DVD)
            String id = scanner.next();   // Mã tài liệu
            String name = scanner.next(); // Tên tài liệu

            if (type.equals("B")) {
                String author = scanner.next();
                int pages = scanner.nextInt();
                bookSection.addItem(new Book(id, name, author, pages));
            } else if (type.equals("D")) {
                String director = scanner.next();
                int duration = scanner.nextInt();
                dvdSection.addItem(new DVD(id, name, director, duration));
            }
        }

        // In danh sách tài liệu theo từng khu vực
        System.out.println("Khu vực Sách:");
        bookSection.displayItems();

        System.out.println("\nKhu vực DVD:");
        dvdSection.displayItems();

        scanner.close(); // Đóng scanner để tránh leak tài nguyên
    }
}
