package bai10.code;

/**
 * Lớp đại diện cho tài liệu Sách.
 */
public class Book extends MediaItem {
    private String author; // Tác giả
    private int pages;    // Số trang

    public Book(String id, String name, String author, int pages) {
        super(id, name);
        this.author = author;
        this.pages = pages;
    }

    @Override
    public String getDisplayInfo() {
        // Định dạng: Tên sách - Tác giả - Số trang
        return name + " - " + author + " - " + pages;
    }
}
