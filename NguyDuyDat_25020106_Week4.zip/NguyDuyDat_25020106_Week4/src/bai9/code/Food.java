package bai9.code;

/**
 * Lớp đại diện cho mặt hàng Thực phẩm.
 */
public class Food extends Product {
    private String expiryDate; // Hạn sử dụng

    public Food(String id, String name, String expiryDate) {
        super(id, name);
        this.expiryDate = expiryDate;
    }

    @Override
    public String getDetailInfo() {
        return name + " - " + expiryDate;
    }
}
