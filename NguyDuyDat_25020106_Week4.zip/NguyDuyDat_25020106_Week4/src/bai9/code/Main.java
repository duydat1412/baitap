package bai9.code;

import java.util.Scanner;

/**
 * Lớp Main để chạy mô phỏng quản lý kho hàng.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Khởi tạo hai kho riêng biệt cho Thực phẩm và Đồ điện tử
        // Sử dụng Generics đảm bảo tính an toàn kiểu dữ liệu (Type Safety)
        Warehouse<Food> foodWarehouse = new Warehouse<>();
        Warehouse<Electronics> electronicsWarehouse = new Warehouse<>();

        if (!scanner.hasNextInt()) {
            scanner.close();
            return;
        }
        int n = scanner.nextInt(); // Số lượng mặt hàng cần nhập

        for (int i = 0; i < n; i++) {
            String type = scanner.next(); // Loại hàng: 'F' (Thực phẩm), 'E' (Điện tử)
            String id = scanner.next();   // Mã hàng
            String name = scanner.next(); // Tên hàng

            if (type.equals("F")) {
                String expiryDate = scanner.next();
                foodWarehouse.importProduct(new Food(id, name, expiryDate));
            } else if (type.equals("E")) {
                int warrantyMonths = scanner.nextInt();
                electronicsWarehouse.importProduct(new Electronics(id, name, warrantyMonths));
            }
        }

        // In kết quả kiểm kê
        System.out.println("Kho Thực phẩm:");
        foodWarehouse.inventoryCheck();

        System.out.println("\nKho Điện tử:");
        electronicsWarehouse.inventoryCheck();

        scanner.close(); // Giải phóng tài nguyên
    }
}
