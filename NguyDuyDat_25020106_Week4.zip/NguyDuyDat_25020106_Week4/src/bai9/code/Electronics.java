package bai9.code;

/**
 * Lớp đại diện cho mặt hàng Đồ điện tử.
 */
public class Electronics extends Product {
    private int warrantyMonths; // Thời gian bảo hành (tháng)

    public Electronics(String id, String name, int warrantyMonths) {
        super(id, name);
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public String getDetailInfo() {
        return name + " - " + warrantyMonths + " tháng bảo hành";
    }
}
