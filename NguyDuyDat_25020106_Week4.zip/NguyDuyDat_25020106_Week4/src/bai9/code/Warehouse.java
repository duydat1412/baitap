package bai9.code;

import java.util.ArrayList;
import java.util.List;

/**
 * Lớp kho hàng sử dụng Generics với Bounded Type Parameter.
 * T chỉ có thể là Product hoặc các lớp con của Product.
 */
public class Warehouse<T extends Product> {
    private List<T> items; // Danh sách các mặt hàng trong kho

    public Warehouse() {
        this.items = new ArrayList<>();
    }

    /**
     * Nhập kho: Thêm một mặt hàng vào danh sách.
     */
    public void importProduct(T item) {
        items.add(item);
    }

    /**
     * Xuất kho: Xóa một mặt hàng khỏi danh sách theo mã.
     */
    public void exportProduct(String id) {
        items.removeIf(item -> item.getId().equals(id));
    }

    /**
     * Kiểm kê: In danh sách các mặt hàng theo yêu cầu.
     */
    public void inventoryCheck() {
        for (T item : items) {
            System.out.println(item.getDetailInfo());
        }
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
