package bai9.code;

/**
 * Lớp trừu tượng đại diện cho một mặt hàng tổng quát trong kho.
 */
public abstract class Product {
    protected String id;   // Mã hàng
    protected String name; // Tên hàng

    public Product(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    /**
     * Phương thức trừu tượng để lấy thông tin chi tiết của từng loại hàng (đa hình).
     */
    public abstract String getDetailInfo();
}
