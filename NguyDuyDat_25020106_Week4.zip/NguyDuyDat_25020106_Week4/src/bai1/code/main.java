package bai1.code;

public class main {
    public static void main(String[] args) {
        Circle circle = new Circle(10,10);
        circle.moveTo(20,20);
    }
}
