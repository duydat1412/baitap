package bai5.code;

public class main {
    public static void main(String[] args) {
        Pair<String,Integer> p0 = new Pair<String,Integer>("Tuổi",20);
        Pair<String,String> p1 = new Pair<String,String>("Mã SV","SV001");
        Pair<Integer,Double> p2 = new Pair<Integer,Double>(105,21.5);
//        Pair<Integer,String> test = new Pair<Integer,String>("Hello World","Bye World"); viết sai sẽ không thể khởi tạo
        System.out.println(p0);
        System.out.println(p1);
        System.out.println(p2);
    }
}
