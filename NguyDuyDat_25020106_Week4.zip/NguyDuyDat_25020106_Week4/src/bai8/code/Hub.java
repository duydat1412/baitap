package bai8.code;

import java.util.ArrayList;
import java.util.List;

public class Hub {
    private List<Device> devices;

    public Hub() {
        this.devices = new ArrayList<>();
    }

    public void addDevice(Device device) {
        devices.add(device);
    }

    public void turnOffAll() {
        System.out.println("Turn Off All Devices:");
        for (Device device : devices) {
            device.turnOff(); // Đa hình: gọi phương thức turnOff của từng loại thiết bị
        }
    }

    public void setupWifi() {
        System.out.println("\nSetup Wifi:");
        for (Device device : devices) {
            // Kiểm tra xem thiết bị có hỗ trợ kết nối Wifi không
            if (device instanceof IWifi) {
                ((IWifi) device).setupWifi();
            }
        }
    }
}
