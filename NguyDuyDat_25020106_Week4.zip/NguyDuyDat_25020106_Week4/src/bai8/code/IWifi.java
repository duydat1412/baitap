package bai8.code;

public interface IWifi {
    void setupWifi(); // Thiết lập kết nối Wifi
}
