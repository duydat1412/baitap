package bai8.code;

public class SmartSpeaker extends Device implements IWifi {
    private int volume; // Âm lượng

    public SmartSpeaker(String id, String name) {
        super(id, name);
        this.volume = 50;
    }

    @Override
    public void setupWifi() {
        System.out.println(name + " connected to wifi");
    }

    public void adjustVolume(int level) {
        this.volume = level;
        System.out.println(name + " volume changed to " + level);
    }
}
