package bai8.code;

public class AirConditioner extends Device implements IWifi {
    public AirConditioner(String id, String name) {
        super(id, name);
    }

    @Override
    public void setupWifi() {
        System.out.println(name + " connected to wifi");
    }
}
