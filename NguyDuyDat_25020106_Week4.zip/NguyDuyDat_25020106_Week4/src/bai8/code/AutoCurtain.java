package bai8.code;

public class AutoCurtain extends Device {
    public AutoCurtain(String id, String name) {
        super(id, name);
    }

    // turnOff (tắt) tương đương với đóng đối với thiết bị này
}
