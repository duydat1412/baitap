package bai8.code;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Hub hub = new Hub();

        if (!scanner.hasNextInt()) {
            scanner.close();
            return;
        }
        int n = scanner.nextInt(); // Số lượng thiết bị

        for (int i = 0; i < n; i++) {
            // Đọc [loại] [id] [tên]
            String type = scanner.next();
            String id = scanner.next();
            String name = scanner.next();

            Device device = null;
            switch (type) {
                case "L":
                    device = new SmartLight(id, name);
                    break;
                case "AC":
                    device = new AirConditioner(id, name);
                    break;
                case "S":
                    device = new SmartSpeaker(id, name);
                    break;
                case "C":
                    device = new AutoCurtain(id, name);
                    break;
            }

            if (device != null) {
                hub.addDevice(device);
            }
        }

        hub.turnOffAll(); // Tắt tất cả thiết bị
        hub.setupWifi();  // Cấu hình Wifi cho các thiết bị hỗ trợ

        scanner.close();
    }
}
