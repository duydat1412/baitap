package bai8.code;

public abstract class Device {
    protected String id;
    protected String name;
    protected boolean status; // true: Bật, false: Tắt

    public Device(String id, String name) {
        this.id = id;
        this.name = name;
        this.status = true; // Mặc định bật khi khởi tạo cho bài tập này
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isStatus() {
        return status;
    }

    public void turnOff() {
        this.status = false;
        System.out.println(name + " turned off");
    }

    public void turnOn() {
        this.status = true;
        System.out.println(name + " turned on");
    }
}
