package bai8.code;

public class SmartLight extends Device {
    private int brightness; // Độ sáng

    public SmartLight(String id, String name) {
        super(id, name);
        this.brightness = 100;
    }

    public void adjustBrightness(int level) {
        this.brightness = level;
        System.out.println(name + " brightness changed to " + level);
    }
}
