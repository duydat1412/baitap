package bai7.code;

public class EmailNotifier implements Notifier {
    @Override
    public void send(String msg) {
        System.out.println("Gui Email: " + msg);
    }
}
