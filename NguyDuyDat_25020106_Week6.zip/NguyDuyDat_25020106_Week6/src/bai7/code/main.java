package bai7.code;

public class main {
    public static void main(String[] args) {

        Notifier emailOnly = new EmailNotifier();
        emailOnly.send("Thong bao bao tri");

        System.out.println();
        Notifier emailAndSms = new SMSNotifier(new EmailNotifier());
        emailAndSms.send("Don hang xac nhan");

        System.out.println();
        Notifier allChannels = new FacebookNotifier(new SMSNotifier(new EmailNotifier()));
        allChannels.send("Khuyen mai dac biet!");
    }
}
