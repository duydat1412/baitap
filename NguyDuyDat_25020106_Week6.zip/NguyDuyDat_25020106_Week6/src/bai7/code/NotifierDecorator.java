package bai7.code;

public abstract class NotifierDecorator implements Notifier {

    protected Notifier wrappedNotifier;

    public NotifierDecorator(Notifier notifier) {
        this.wrappedNotifier = notifier;
    }

    @Override
    public void send(String msg) {
        wrappedNotifier.send(msg); // gọi hàm gốc
    }
}
