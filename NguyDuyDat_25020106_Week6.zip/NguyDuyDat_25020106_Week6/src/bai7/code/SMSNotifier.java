package bai7.code;

public class SMSNotifier extends NotifierDecorator {

    public SMSNotifier(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String msg) {
        super.send(msg); // gọi các kênh bên trong
        System.out.println("Gui SMS: " + msg); // gửi thêm SMS
    }
}
