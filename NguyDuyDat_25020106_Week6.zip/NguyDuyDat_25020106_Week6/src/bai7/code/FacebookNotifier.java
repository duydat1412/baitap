package bai7.code;

public class FacebookNotifier extends NotifierDecorator {

    public FacebookNotifier(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String msg) {
        super.send(msg); // gọi các kênh bên trong
        System.out.println("Gui Facebook: " + msg); // gửi thêm Facebook
    }
}
