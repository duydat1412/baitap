package bai7.code;

public interface Notifier {
    void send(String msg);
}
