package bai4.code;

import java.util.Arrays;

// bọc LegacySorter để dùng được với interface Sorter
public class SorterAdapter implements Sorter {

    private LegacySorter legacySorter;

    public SorterAdapter() {
        this.legacySorter = new LegacySorter();
    }

    @Override
    public int[] sort(int[] arr) {
        int[] copy = Arrays.copyOf(arr, arr.length); // copy để không đụng mảng gốc
        legacySorter.quickSort(copy); // gọi hàm cũ
        return copy;
    }
}
