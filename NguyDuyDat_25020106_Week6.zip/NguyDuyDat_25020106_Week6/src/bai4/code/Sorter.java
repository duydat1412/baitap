package bai4.code;

public interface Sorter {
    int[] sort(int[] arr);
}
