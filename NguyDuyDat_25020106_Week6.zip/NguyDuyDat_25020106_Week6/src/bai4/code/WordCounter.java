package bai4.code;

import java.util.ArrayList;
import java.util.HashMap;

public class    WordCounter {

    private HashMap<String, Integer> wordMap;

    public WordCounter() {
        wordMap = new HashMap<>();
    }

    public void analyze(String text) {

        String normalized = text.toLowerCase().replaceAll("[^a-z\\s]", "");

        String[] words = normalized.split("\\s+");

        for (String word : words) {
            if (word.isEmpty()) continue;

            if (wordMap.containsKey(word)) {
                // tuong tu nhu bai 3, kiem tra xem co key chua, chua co thi tao moi va gan count = 1
                int oldCount = wordMap.get(word);
                wordMap.put(word, oldCount + 1);
            } else {
                wordMap.put(word, 1);
            }
        }
    }

    public void displayResult() {
        System.out.println("DANH SACH TU VA SO LAN XUAT HIEN : ");
        for (String word : wordMap.keySet()) { //keySet return về set chứa các keys
            System.out.println("  \"" + word + "\" -> " + wordMap.get(word) + " lan");
        }

        String mostFreqWord = "";
        int maxCount = 0;

        for (String word : wordMap.keySet()) {
            if (wordMap.get(word) > maxCount) {
                maxCount = wordMap.get(word);
                mostFreqWord = word;
            }
        }

        System.out.println("\nTU XUAT HIEN NHIEU NHAT : ");
        System.out.println("  \"" + mostFreqWord + "\" -> " + maxCount + " lan");
    }


    public static void analyzeWithArrayList(String text) {
        System.out.println("\nPHAN TICH BANG ARRAYLIST : ");

        String normalized = text.toLowerCase().replaceAll("[^a-z\\s]", "");
        String[] words = normalized.split("\\s+");

        ArrayList<String> wordList  = new ArrayList<>();
        ArrayList<Integer> countList = new ArrayList<>();

        for (String word : words) {
            if (word.isEmpty()) continue;

            if (wordList.contains(word)) {
                int index = wordList.indexOf(word);
                countList.set(index, countList.get(index) + 1);
            } else {
                wordList.add(word);
                countList.add(1);
            }
        }

        for (int i = 0; i < wordList.size(); i++) {
            System.out.println("  \"" + wordList.get(i) + "\" -> " + countList.get(i) + " lan");
        }
    }
}
