package bai4.code;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class main {
    public static void main(String[] args) {

        // Adapter
        int[] arr = {5, 2, 8, 1, 9, 3};
        System.out.println("Mang ban dau: " + Arrays.toString(arr));

        Sorter sorter = new SorterAdapter(); // dùng adapter gọi quickSort từ lớp cũ
        int[] sorted = sorter.sort(arr);

        System.out.println("Sau khi sap xep: " + Arrays.toString(sorted));
        System.out.println("Mang goc (khong doi): " + Arrays.toString(arr));

        // Prototype
        System.out.println();
        List<String> sections = new ArrayList<>();
        sections.add("Gioi thieu");
        sections.add("Noi dung chinh");
        sections.add("Ket luan");

        ReportTemplate original = new ReportTemplate("Bao cao goc", "Footer goc", sections);
        System.out.println("Ban goc: " + original);

        ReportTemplate cloned = original.clone(); // clone bản gốc
        cloned.setTitle("Bao cao ban sao");
        cloned.getSections().add("Phu luc"); // thêm section vào bản sao

        System.out.println("Ban sao: " + cloned);
        System.out.println("Ban goc (khong bi anh huong): " + original);
    }
}
