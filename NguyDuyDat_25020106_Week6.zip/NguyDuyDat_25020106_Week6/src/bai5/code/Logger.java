package bai5.code;

public class Logger {

    private static Logger instance;

    private Logger() {} // constructor private, không tạo từ bên ngoài được

    public static Logger getInstance() {
        if (instance == null) { // chưa có thì tạo
            instance = new Logger();
        }
        return instance;
    }

    public void log(String message) {
        System.out.println("[LOG] " + message);
    }
}
