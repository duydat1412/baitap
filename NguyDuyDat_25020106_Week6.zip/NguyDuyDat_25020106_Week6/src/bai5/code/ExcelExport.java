package bai5.code;

public class ExcelExport implements Exporter {
    @Override
    public void export(String data) {
        System.out.println("Xuat Excel: " + data);
    }
}
