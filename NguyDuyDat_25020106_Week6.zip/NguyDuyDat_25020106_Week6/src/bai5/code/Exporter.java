package bai5.code;

public interface Exporter {
    void export(String data);
}
