package bai5.code;

public interface Player {
    void play(String song);
}
