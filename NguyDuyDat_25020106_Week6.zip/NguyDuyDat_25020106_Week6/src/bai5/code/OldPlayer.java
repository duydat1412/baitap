package bai5.code;

// lớp cũ, không sửa
public class OldPlayer {
    public void playMusic(String track) {
        System.out.println("OldPlayer dang phat: " + track);
    }
}
