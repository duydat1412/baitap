package bai5.code;


public class Book {
    private String id;      // Ma sach (duy nhat)
    private String title;   // Ten sach
    private String author;  // Tac gia
    private int year;       // Nam xuat ban

    public Book(String id, String title, String author, int year) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.year = year;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getYear() { return year; }

    @Override
    public String toString() {
        return "[" + id + "] " + title + " - " + author + " (" + year + ")";
    }
}
