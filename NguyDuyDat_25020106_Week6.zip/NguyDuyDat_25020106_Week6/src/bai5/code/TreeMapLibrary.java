package bai5.code;

import java.util.TreeMap;

public class TreeMapLibrary {

    private TreeMap<String, Book> books;

    public TreeMapLibrary() {
        books = new TreeMap<>();
    }


    public void add(Book book) {
        books.put(book.getId(), book);
        System.out.println("[TreeMap] Da them: " + book);
    }

    public Book findById(String id) {
        return books.get(id);
    }


    public void deleteById(String id) {
        if (books.containsKey(id)) {
            books.remove(id);
            System.out.println("[TreeMap] Da xoa sach id: " + id);
        } else {
            System.out.println("[TreeMap] Khong tim thay sach id: " + id);
        }
    }

    public void printAll() {
        System.out.println("[TreeMap] Danh sach sach (sap xep theo id, " + books.size() + " quyen):");
        for (Book b : books.values()) {
            System.out.println("  " + b);
        }
    }
}
