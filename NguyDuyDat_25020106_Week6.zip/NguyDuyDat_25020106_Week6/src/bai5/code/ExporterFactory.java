package bai5.code;

// tạo Exporter theo type
public class ExporterFactory {

    public static Exporter createExporter(String type) {
        switch (type.toLowerCase()) {
            case "pdf":
                return new PdfExport();
            case "excel":
                return new ExcelExport();
            default:
                System.out.println("Loai export khong hop le: " + type);
                return null;
        }
    }
}
