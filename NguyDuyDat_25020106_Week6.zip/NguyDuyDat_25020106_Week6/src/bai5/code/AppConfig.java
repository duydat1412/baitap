package bai5.code;

import java.util.HashMap;
import java.util.Map;

public class AppConfig implements Cloneable {

    private String appName;
    private Map<String, String> settings;

    public AppConfig(String appName, Map<String, String> settings) {
        this.appName = appName;
        this.settings = settings;
    }

    @Override
    public AppConfig clone() {
        try {
            AppConfig cloned = (AppConfig) super.clone();
            cloned.settings = new HashMap<>(this.settings); // deep copy map
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    public String getAppName() { return appName; }
    public void setAppName(String appName) { this.appName = appName; }
    public Map<String, String> getSettings() { return settings; }

    @Override
    public String toString() {
        return "AppConfig{appName='" + appName + "', settings=" + settings + "}";
    }
}
