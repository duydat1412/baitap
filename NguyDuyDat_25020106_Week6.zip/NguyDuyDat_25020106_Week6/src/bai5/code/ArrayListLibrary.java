package bai5.code;

import java.util.ArrayList;

public class ArrayListLibrary {

    private ArrayList<Book> books;

    public ArrayListLibrary() {
        books = new ArrayList<>();
    }

    public void add(Book book) {
        books.add(book);
        System.out.println("[ArrayList] Da them: " + book);
    }

    public Book findById(String id) { // phai duyet tung phan tu trong list
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId().equals(id)) {
                return books.get(i);
            }
        }
        return null;
    }

    public void deleteById(String id) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId().equals(id)) { // phai tim index truoc
                books.remove(i);
                System.out.println("[ArrayList] Da xoa sach id: " + id);
                return;
            }
        }
        System.out.println("[ArrayList] Khong tim thay sach id: " + id);
    }

    public void printAll() {
        System.out.println("[ArrayList] Danh sach sach (" + books.size() + " quyen):");
        for (Book b : books) {
            System.out.println("  " + b);
        }
    }
}
