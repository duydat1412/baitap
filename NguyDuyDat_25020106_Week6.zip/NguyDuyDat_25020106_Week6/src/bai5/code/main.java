package bai5.code;

import java.util.HashMap;
import java.util.Map;

public class main {
    public static void main(String[] args) {

        // Singleton
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        logger1.log("Ung dung khoi dong");
        System.out.println("logger1 == logger2 ? " + (logger1 == logger2));

        // Factory Method
        System.out.println();
        Exporter pdf = ExporterFactory.createExporter("pdf");
        Exporter excel = ExporterFactory.createExporter("excel");
        pdf.export("Du lieu bao cao");
        excel.export("Bang tinh luong");

        // Adapter
        System.out.println();
        Player player = new PlayerAdapter();
        player.play("Shape of You - Ed Sheeran");

        // Prototype
        System.out.println();
        Map<String, String> settings = new HashMap<>();
        settings.put("theme", "dark");
        settings.put("language", "vi");

        AppConfig original = new AppConfig("MyApp", settings);
        AppConfig cloned = original.clone();
        cloned.setAppName("MyApp - Copy");
        cloned.getSettings().put("theme", "light"); // sửa bản sao

        System.out.println("Ban goc: " + original);
        System.out.println("Ban sao: " + cloned);
    }
}
