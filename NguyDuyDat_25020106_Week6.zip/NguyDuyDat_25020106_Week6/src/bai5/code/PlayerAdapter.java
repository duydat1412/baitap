package bai5.code;

// bọc OldPlayer cho tương thích interface Player
public class PlayerAdapter implements Player {

    private OldPlayer oldPlayer;

    public PlayerAdapter() {
        this.oldPlayer = new OldPlayer();
    }

    @Override
    public void play(String song) {
        oldPlayer.playMusic(song); // gọi hàm cũ
    }
}
