package bai5.code;

import java.util.HashMap;

public class HashMapLibrary {

    private HashMap<String, Book> books;

    public HashMapLibrary() {
        books = new HashMap<>();
    }

    public void add(Book book) {
        books.put(book.getId(), book);
        System.out.println("[HashMap] Da them: " + book);
    }

    public Book findById(String id) {
        return books.get(id); // Tra ve null neu khong tim thay
    }

    public void deleteById(String id) {
        if (books.containsKey(id)) {
            books.remove(id);
            System.out.println("[HashMap] Da xoa sach id: " + id);
        } else {
            System.out.println("[HashMap] Khong tim thay sach id: " + id);
        }
    }

    public void printAll() {
        System.out.println("[HashMap] Danh sach sach (" + books.size() + " quyen):");
        for (Book b : books.values()) {
            System.out.println("  " + b);
        }
    }
}
