package bai5.code;

public class PdfExport implements Exporter {
    @Override
    public void export(String data) {
        System.out.println("Xuat PDF: " + data);
    }
}
