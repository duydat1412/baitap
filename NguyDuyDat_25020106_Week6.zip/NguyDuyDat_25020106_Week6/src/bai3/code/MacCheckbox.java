package bai3.code;

public class MacCheckbox implements UserUI.Checkbox{
    @Override
    public void render() {
        System.out.println("Mac Checkbox rendered.");
    }
}
