package bai3.code;

public class WindowsCheckbox implements UserUI.Checkbox{
    @Override
    public void render() {
        System.out.println("Windows Checkbox rendered");
    }
}
