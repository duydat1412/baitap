package bai3.code;

public interface UserUI {
    interface Button {
        void render();
    }
    interface Checkbox {
        void render();
    }
}
