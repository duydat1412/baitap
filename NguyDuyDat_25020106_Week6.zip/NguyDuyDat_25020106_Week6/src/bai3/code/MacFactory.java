package bai3.code;

public class MacFactory implements UIFactory {
    @Override
    public UserUI.Button createButton() {
        System.out.println("Creating Mac Button...");
        return new MacButton();
    }

    @Override
    public UserUI.Checkbox createCheckbox() {
        System.out.println("Creating Mac Checkbox...");
        return new MacCheckbox();
    }
}