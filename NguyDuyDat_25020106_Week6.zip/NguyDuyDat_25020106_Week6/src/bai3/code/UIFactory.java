package bai3.code;

public interface UIFactory {
    UserUI.Button createButton();
    UserUI.Checkbox createCheckbox();
}
