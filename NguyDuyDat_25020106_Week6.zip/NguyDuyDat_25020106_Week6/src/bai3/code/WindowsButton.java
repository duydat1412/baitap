package bai3.code;

public class WindowsButton implements UserUI.Button {
    @Override
    public void render() {
        System.out.println("Windows button rendered.");
    }
}
