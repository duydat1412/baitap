package bai3.code;

public class WindowsFactory implements UIFactory{
    @Override
    public UserUI.Button createButton() {
        System.out.println("Creating Windows Button..");
        return new WindowsButton();
    }

    @Override
    public UserUI.Checkbox createCheckbox() {
        System.out.println("Creating Windows Checkbox..");
        return new WindowsCheckbox();
    }
}
