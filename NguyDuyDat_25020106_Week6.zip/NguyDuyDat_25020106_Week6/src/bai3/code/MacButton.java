package bai3.code;

public class MacButton implements UserUI.Button{
    @Override
    public void render() {
        System.out.println("Mac Button Rendered.");
    }
}
