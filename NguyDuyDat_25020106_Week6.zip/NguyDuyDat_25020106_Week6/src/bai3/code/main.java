package bai3.code;
import java.util.Scanner;
public class main {
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        System.out.println("Input type (Mac/Win) : ");
       String type = sc.nextLine().trim();

       UIFactory factory;

       if (type.equalsIgnoreCase("Win")) {
           factory = new WindowsFactory();
       } else if (type.equalsIgnoreCase("Mac")) {
           factory = new MacFactory();
       } else {
           System.out.println("Invalid type!");
           return;
       }
        UserUI.Button button = factory.createButton();
        UserUI.Checkbox checkbox = factory.createCheckbox();

        button.render();
        checkbox.render();
    }
}

