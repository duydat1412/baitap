package bai1.code;

public class AppConfig {
    private String appName;
    private String version;
    private String logLevel;

    private static volatile AppConfig instance;

    private AppConfig() {
           this.appName="Hum Hum APP";
           this.version="1.0";
           this.logLevel="first commit";
    }

    public static AppConfig getInstance() {
        if (instance == null) { // khi luồng đi vào thì kiểm tra xem đã có đối tượng nào dc tạo chưa
            synchronized (AppConfig.class) { //nếu chưa được tạo thì trao chìa khó cho luồng
                if (instance== null) { // check lại laanf nữa xem có luồng nào khác vào trước, tạo đối tượng rồi ra trước rồi không
                    instance = new AppConfig(); // chưa có thì tạo
                }
            }
        }
        return instance; // tạo xong thì trả về
    }
}
