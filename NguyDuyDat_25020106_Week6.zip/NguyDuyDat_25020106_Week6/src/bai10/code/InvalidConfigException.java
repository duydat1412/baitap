package bai10.code;

public class InvalidConfigException extends Exception {
    public InvalidConfigException(String message) {
        super(message); // Truyen thong bao len lop cha Exception
    }
}
