package bai10.code;

public class Logger {

    private static Logger instance;

    private Logger() {} // constructor private

    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger(); // lazy init
        }
        return instance;
    }

    public void logInfo(String message) {
        System.out.println("[INFO] " + message);
    }

    public void logError(String message) {
        System.out.println("[ERROR] " + message);
    }
}
