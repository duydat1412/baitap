package bai10.code;

public class main {
    public static void main(String[] args) {

        Logger logger1 = Logger.getInstance();
        logger1.logInfo("Ung dung khoi dong");
        logger1.logError("Khong tim thay file");

        Logger logger2 = Logger.getInstance();
        logger2.logInfo("Dang ket noi DB");

        System.out.println(logger1 == logger2); // true
    }
}
