package bai2.code;

public class SmsApp extends NotificationApp{
    @Override
    public Notification createNotification() {
        return new SmsNotification();
    }
}
