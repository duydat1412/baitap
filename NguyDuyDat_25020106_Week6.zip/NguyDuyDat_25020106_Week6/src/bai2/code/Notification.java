package bai2.code;

public interface Notification {
    void send(String msg);
}
