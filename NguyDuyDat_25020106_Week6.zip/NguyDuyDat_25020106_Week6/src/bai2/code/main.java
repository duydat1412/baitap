package bai2.code;
import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        System.out.println("input type (Sms/Email) : ");
        Scanner sc = new Scanner(System.in);
        String type = sc.nextLine().trim();

        if (!type.equals("Email") && !type.equals("Sms")) {
            System.out.println("Sai dinh dang..");
        } else {
            switch (type) {
                case "Email" :
                    System.out.println("nhap msg : ");
                    String msg = sc.nextLine();
                    EmailApp emailApp = new EmailApp();
                    emailApp.notifyUser(msg);
                case "Sms" :
                    System.out.println("nhap msg : ");
                    String msg1 = sc.nextLine();
                    SmsApp smsApp = new SmsApp();
                    smsApp.notifyUser(msg1);
            }
        }
    }
}
