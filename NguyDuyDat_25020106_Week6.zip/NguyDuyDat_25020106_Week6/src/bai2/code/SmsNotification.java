package bai2.code;

public class SmsNotification implements Notification {
    @Override
    public void send(String msg) {
        System.out.println("Send sms: "+ msg);
    }
}
