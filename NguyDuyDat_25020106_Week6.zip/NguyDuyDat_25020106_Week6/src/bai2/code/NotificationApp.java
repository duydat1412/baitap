package bai2.code;

public abstract class NotificationApp {
    public void notifyUser(String msg) {
        Notification notification = createNotification();
        notification.send(msg);
    }
    public abstract Notification createNotification();
}
