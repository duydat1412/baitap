#!/bin/bash

# Di chuyển đến thư mục chứa script này
cd "$(dirname "$0")"

echo "=== BẮT ĐẦU CHẠY TOÀN BỘ 10 BÀI TẬP ==="

# Vòng lặp từ bài 1 đến bài 10
for i in {1..10}
do
    current_bai="bai$i"
    
    # Kiểm tra xem thư mục bài đó có tồn tại không
    if [ -d "$current_bai" ]; then
        echo "------------------------------------------"
        echo ">>> Đang thực thi: $current_bai"
        
        # Di chuyển vào thư mục của bài đó
        pushd "$current_bai" > /dev/null
        
        # Kiểm tra nếu có file run.sh riêng của bài đó thì chạy nó
        if [ -f "run.sh" ]; then
            chmod +x run.sh
            ./run.sh
        else
            # Nếu không có run.sh riêng, tự động biên dịch và chạy file trong code/
            echo "Không tìm thấy run.sh, đang tự động chạy file trong code/..."
            javac code/*.java
            # Giả sử class chính là Main, thay đổi nếu cần
            java -cp "code:lib/*" Main 
        fi
        
        # Quay trở lại thư mục src
        popd > /dev/null
    else
        echo "Thư mục $current_bai không tồn tại, bỏ qua."
    fi
done

echo "------------------------------------------"
echo "=== ĐÃ HOÀN THÀNH TẤT CẢ ==="