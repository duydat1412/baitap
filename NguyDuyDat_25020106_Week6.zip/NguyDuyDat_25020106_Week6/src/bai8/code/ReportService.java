package bai8.code;

public class ReportService {

    private ReportFormatter formatter;

    public ReportService(ReportFormatter formatter) {
        this.formatter = formatter; // Strategy Pattern: nhận từ constructor
    }

    public void export(Report data) {
        String result = formatter.format(data);
        System.out.println("Ket qua export:");
        System.out.println(result);
    }
}
