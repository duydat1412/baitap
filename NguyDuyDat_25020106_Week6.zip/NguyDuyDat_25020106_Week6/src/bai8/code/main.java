package bai8.code;

public class main {
    public static void main(String[] args) {

        Report report = new Report("Bao cao Q1", "Doanh thu tang 15%");

        System.out.println("--- Export JSON ---");
        ReportService jsonService = new ReportService(new JsonFormatter());
        jsonService.export(report);

        System.out.println();
        System.out.println("--- Export XML ---");
        ReportService xmlService = new ReportService(new XmlFormatter());
        xmlService.export(report);
    }
}
