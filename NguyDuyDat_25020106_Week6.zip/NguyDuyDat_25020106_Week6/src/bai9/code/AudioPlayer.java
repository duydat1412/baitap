package bai9.code;

public class AudioPlayer implements AudioPlayable {
    @Override
    public void playAudio(String fileName) {
        System.out.println("Dang phat audio: " + fileName);
    }
}
