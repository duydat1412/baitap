package bai9.code;

public class VideoPlayer implements VideoPlayable {
    @Override
    public void playVideo(String fileName) {
        System.out.println("Dang phat video: " + fileName);
    }
}
