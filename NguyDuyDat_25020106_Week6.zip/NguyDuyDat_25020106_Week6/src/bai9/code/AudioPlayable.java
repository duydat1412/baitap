package bai9.code;

public interface AudioPlayable {
    void playAudio(String fileName);
}
