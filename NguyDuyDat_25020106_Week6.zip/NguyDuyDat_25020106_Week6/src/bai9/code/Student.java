package bai9.code;

import java.io.Serializable;

/**
 * Lop Student luu thong tin sinh vien.
 *
 * Serializable:
 *   - La mot interface danh dau (marker interface), khong co phuong thuc.
 *   - Khi mot lop implements Serializable, Java cho phep chuyen doi
 *     doi tuong thanh chuoi byte de ghi vao file hoac truyen qua mang.
 *   - ObjectOutputStream can doi tuong phai Serializable moi ghi duoc.
 *   - serialVersionUID: ID phien ban de kiem tra tuong thich khi doc lai.
 */
public class Student implements Serializable {
    private static final long serialVersionUID = 1L; // Kiem soat phien ban Serializable

    private String id;
    private String name;
    private double gpa;

    public Student(String id, String name, double gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Name: " + name + " | GPA: " + gpa;
    }
}
