package bai9.code;

public class main {
    public static void main(String[] args) {

        AudioPlayable audioPlayer = new AudioPlayer();
        VideoPlayable videoPlayer = new VideoPlayer();

        MediaPlayer mediaPlayer = new MediaPlayer(audioPlayer, videoPlayer);

        mediaPlayer.playMusic("song.mp3");
        mediaPlayer.playMovie("movie.mp4");
    }
}
