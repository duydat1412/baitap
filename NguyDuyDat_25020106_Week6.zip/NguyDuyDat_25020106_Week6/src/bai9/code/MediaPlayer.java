package bai9.code;

public class MediaPlayer {

    private AudioPlayable audioPlayer;
    private VideoPlayable videoPlayer;

    public MediaPlayer(AudioPlayable audioPlayer, VideoPlayable videoPlayer) { // qua constructor (DIP)
        this.audioPlayer = audioPlayer;
        this.videoPlayer = videoPlayer;
    }

    public void playMusic(String fileName) {
        audioPlayer.playAudio(fileName);
    }

    public void playMovie(String fileName) {
        videoPlayer.playVideo(fileName);
    }
}
