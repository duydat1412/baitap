package bai9.code;

public interface VideoPlayable {
    void playVideo(String fileName);
}
