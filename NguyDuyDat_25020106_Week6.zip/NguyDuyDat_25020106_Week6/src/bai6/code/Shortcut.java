package bai6.code;

public class Shortcut extends FileSystemItem {

    private String targetPath;

    public Shortcut(String name, String targetPath) {
        super(name);
        this.targetPath = targetPath;
    }

    @Override
    public void print(String indent) {
        System.out.println(indent + "Shortcut: " + name + " -> " + targetPath);
    }
}
