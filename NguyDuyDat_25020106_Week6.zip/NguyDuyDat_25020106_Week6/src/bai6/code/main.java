package bai6.code;

public class main {
    public static void main(String[] args) {

        FileItem file1 = new FileItem("readme.txt", 5);
        FileItem file2 = new FileItem("main.java", 12);
        FileItem file3 = new FileItem("report.pdf", 120);
        FileItem file4 = new FileItem("data.csv", 45);

        Shortcut shortcut1 = new Shortcut("game.lnk", "D:/Games/game.exe");
        Shortcut shortcut2 = new Shortcut("server.lnk", "/usr/bin/server");

        Folder srcFolder = new Folder("src");
        srcFolder.addItem(file2);
        srcFolder.addItem(file4);

        Folder docsFolder = new Folder("docs");
        docsFolder.addItem(file3);
        docsFolder.addItem(shortcut2);

        Folder root = new Folder("root");
        root.addItem(file1);
        root.addItem(srcFolder);
        root.addItem(docsFolder);
        root.addItem(shortcut1);

        root.print(""); // in cây thư mục từ gốc
    }
}
