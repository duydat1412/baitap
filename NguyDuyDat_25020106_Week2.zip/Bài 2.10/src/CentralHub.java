public class CentralHub {
    public void registerDevice(SmartLight light) {
        System.out.println("[HUB] đang kết nối với thiết bị: " + light.getName());
    }
}
