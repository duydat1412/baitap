public class Student {
    private String id;
    private String name;
    private String email;
    private double gpa;

    public Student() {
        this.id = "";
        this.name = "";
        this.email = "";
        this.gpa = 0.0;
    }
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.email = "";
        this.gpa = 0.0;
    }
    public Student(Student other) {
        this.id = other.id;
        this.name = other.name;
        this.email = other.email;
        this.gpa = other.gpa;
    }

    public String getId() {
        return this.id;
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public double getGpa() {
        return this.gpa;
    }
    public void setId(String id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void setGpa(double gpa) {
        if (gpa >= 0 && gpa <= 4.0) {
            this.gpa = gpa;
        } else System.out.println("Loi: GPA phai nam trong khoang 0.0 den 4.0");
    }
    
    public void display() {
        System.out.println("Ma SV: " + id);
        System.out.println("Ten: " + name);
        System.out.println("Email: " + email);
        System.out.println("GPA: " + gpa);
        System.out.println("          ");
    }
    
    public static void main(String[] args) {
        Student student1 = new Student();
        student1.setId("25020100");
        student1.setName("Nguyen Van A");
        student1.setEmail("25020100@vnu.edu.vn");
        student1.setGpa(3.5);
        
        Student student2 = new Student("25020106", "Nguy Duy Dat");
        student2.setEmail("25020106@vnu.edu.vn");
        student2.setGpa(3.6);
        
        Student student3 = new Student(student2);

        student1.setGpa(-1.0);
        student1.setGpa(5.0);

        student1.display();
        student2.display();
        student3.display();
    }
}