## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
Quáº£n lÃ½ tÃ i khoáº£n vÃ  danh sÃ¡ch cÃ¡c giao dá»‹ch Ä‘Ã£ thá»±c hiá»‡n.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Sá»­ dá»¥ng lá»›p **Immutable (Báº¥t biáº¿n)** cho `Transaction` vá»›i tá»« khÃ³a `final` Ä‘á»ƒ Ä‘áº£m báº£o lá»‹ch sá»­ giao dá»‹ch khÃ´ng bá»‹ thay Ä‘á»•i sau khi táº¡o. Sá»­ dá»¥ng máº£ng Ä‘á»‘i tÆ°á»£ng Ä‘á»ƒ quáº£n lÃ½ táº­p há»£p.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai6.code.main