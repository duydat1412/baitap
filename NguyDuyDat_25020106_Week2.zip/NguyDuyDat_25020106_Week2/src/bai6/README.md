## Tóm tắt ý tưởng chính
Quản lý tài khoản và danh sách các giao dịch đã thực hiện.

## Hướng tiếp cận và Ưu điểm
Sử dụng lớp **Immutable (Bất biến)** cho `Transaction` với từ khóa `final` để đảm bảo lịch sử giao dịch không bị thay đổi sau khi tạo. Sử dụng mảng đối tượng để quản lý tập hợp.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai6.code.main