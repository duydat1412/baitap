package bai6.code;
public class main {
    public static void main(String[] args) {
        Transaction t1 = new Transaction("quatang8thang3","500000","8/3/2026");
        Transaction t2 = new Transaction("lixitetnguyendan","500000","17/2/2026");

        Account acc = new Account("14122007",20000000.0);

        acc.addTransaction(t1);
        acc.addTransaction(t2);

        Transaction[] hackedHistory = acc.getHistory();
        hackedHistory[0]=null;
        hackedHistory[1]= new Transaction("hackedtransaction","50000000","8/3/2026");

        System.out.println("history da bi sua: ");
        System.out.println(hackedHistory[0]);
        System.out.println(hackedHistory[1]);

        System.out.println("history goc sau khi da bi hacker truy cap: ");
        Transaction[] baseHistory = acc.getHistory();
        System.out.println(baseHistory[0]);
        System.out.println(baseHistory[1]);

    }
}

