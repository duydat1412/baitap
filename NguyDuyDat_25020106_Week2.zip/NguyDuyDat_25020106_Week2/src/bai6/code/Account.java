package bai6.code;
public class Account {
    private String accountId;
    private double balance;
    private Transaction[] history;

    public Account(String accountId, double balance) {
        this.accountId = accountId;
        this.balance = balance;
        this.history = new Transaction[0];
    }

    public void addTransaction(Transaction t) {
        Transaction[] newHistory = new Transaction[history.length +1];
        for (int i=0;i<history.length;i++) {
            newHistory[i]=history[i];
        }
        newHistory[history.length] =t;
        history=newHistory;
    }
    public Transaction[] getHistory() {
        Transaction[] copy = new Transaction[history.length];
        for (int i=0;i < history.length;i++) {
            copy[i]=history[i];
        }
        return copy;

    }
}

