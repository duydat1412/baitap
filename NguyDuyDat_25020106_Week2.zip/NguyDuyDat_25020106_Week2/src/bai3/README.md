## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
Sá»­ dá»¥ng lá»›p bao bá»c (Wrapper class) Ä‘á»ƒ thá»±c hiá»‡n hoÃ¡n vá»‹ (swap) giÃ¡ trá»‹ cá»§a hai sá»‘ nguyÃªn thÃ´ng qua tham chiáº¿u Ä‘á»‘i tÆ°á»£ng.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Minh há»a sá»± khÃ¡c biá»‡t giá»¯a **Tham trá»‹ (Pass-by-value)** vÃ  **Tham chiáº¿u (Pass-by-reference)** trong Java. Báº±ng cÃ¡ch bao bá»c primitive type vÃ o má»™t Object, ta cÃ³ thá»ƒ thay Ä‘á»•i tráº¡ng thÃ¡i cá»§a Ä‘á»‘i tÆ°á»£ng bÃªn trong phÆ°Æ¡ng thá»©c `swap`.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai3.code.NumberWrapper