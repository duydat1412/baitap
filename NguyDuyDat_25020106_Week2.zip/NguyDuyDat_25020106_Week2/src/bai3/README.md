## Tóm tắt ý tưởng chính
Sử dụng lớp bao bọc (Wrapper class) để thực hiện hoán vị (swap) giá trị của hai số nguyên thông qua tham chiếu đối tượng.

## Hướng tiếp cận và Ưu điểm
Minh họa sự khác biệt giữa **Tham trị (Pass-by-value)** và **Tham chiếu (Pass-by-reference)** trong Java. Bằng cách bao bọc primitive type vào một Object, ta có thể thay đổi trạng thái của đối tượng bên trong phương thức `swap`.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai3.code.NumberWrapper