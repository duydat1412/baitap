﻿package bai4.code;
public class main {
    public static void main(String[] args) {
        Employee emp1 = new Employee("Nguy Duy Dat",new MyDate(1,1,2000));
        Employee emp2 = new Employee(emp1);
        emp1.birthday.setDay(2);
        emp1.birthday.setMonth(2);
        emp1.birthday.setYear(2022);
        System.out.println(emp2.birthday.getDay());
    }
}

