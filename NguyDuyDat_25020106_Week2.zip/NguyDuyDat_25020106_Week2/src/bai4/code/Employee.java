package bai4.code;
public class Employee {
    public String name;
    public MyDate birthday;

    public Employee(String ten, MyDate ngaysinh) {

        this.name = ten;
        this.birthday = ngaysinh;

    }

    public Employee(Employee other) {
        this.name = other.name;
        this.birthday = new MyDate(other.birthday.getDay(), other.birthday.getMonth(), other.birthday.getYear());
    }

}

