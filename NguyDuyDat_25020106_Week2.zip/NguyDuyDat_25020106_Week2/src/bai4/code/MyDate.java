package bai4.code;
public class MyDate {
    public int day;
    public int month;
    public int year;

    public MyDate(int ngay, int thang, int nam) {
        this.day = ngay;
        this.month = thang;
        this.year = nam;
    }
    public void setDay(int day) {
        this.day=day;
    }
    public int getDay() {
        return day;
    }
    public void setMonth(int n) {
        this.month=n;
    }
    public int getMonth() {
        return month;
    }
    public void setYear(int n) {
        this.year=n;
    }
    public int getYear() {
        return year;
    }

}

