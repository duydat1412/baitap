## Tóm tắt ý tưởng chính
Mô hình hóa mối quan hệ giữa Nhân viên và Ngày tháng thông qua các lớp `Employee` và `MyDate`.

## Hướng tiếp cận và Ưu điểm
Sử dụng tính chất **Composition (Thành phần)**: Một đối tượng `Employee` chứa một đối tượng `MyDate` làm thuộc tính. Áp dụng **Deep Copy** trong Copy Constructor để tránh hiện tượng chia sẻ tham chiếu không mong muốn.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai4.code.main