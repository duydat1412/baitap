## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
MÃ´ hÃ¬nh hÃ³a má»‘i quan há»‡ giá»¯a NhÃ¢n viÃªn vÃ  NgÃ y thÃ¡ng thÃ´ng qua cÃ¡c lá»›p `Employee` vÃ  `MyDate`.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Sá»­ dá»¥ng tÃ­nh cháº¥t **Composition (ThÃ nh pháº§n)**: Má»™t Ä‘á»‘i tÆ°á»£ng `Employee` chá»©a má»™t Ä‘á»‘i tÆ°á»£ng `MyDate` lÃ m thuá»™c tÃ­nh. Ãp dá»¥ng **Deep Copy** trong Copy Constructor Ä‘á»ƒ trÃ¡nh hiá»‡n tÆ°á»£ng chia sáº» tham chiáº¿u khÃ´ng mong muá»‘n.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai4.code.main