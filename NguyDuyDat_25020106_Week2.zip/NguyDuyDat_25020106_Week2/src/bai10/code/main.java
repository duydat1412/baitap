package bai10.code;
public class main {
    public static void main(String[] args) {
        CentralHub hub = new CentralHub();
        SmartLight l1 = new SmartLight("L01","ÄÃ¨n phÃ²ng khÃ¡ch",80);
        SmartLight l2 = new SmartLight("L02","ÄÃ¨n ngá»§");

        l2.setBrightness("ECO");

        l1.connectToHub(hub);
        l2.connectToHub(hub);

        System.out.println(l1.getBrightness());
        System.out.println(l2.getBrightness());
    }
}

