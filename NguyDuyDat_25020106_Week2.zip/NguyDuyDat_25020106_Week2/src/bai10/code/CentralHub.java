﻿package bai10.code;
public class CentralHub {
    public void registerDevice(SmartLight light) {
        System.out.println("[HUB] Ä‘ang káº¿t ná»‘i vá»›i thiáº¿t bá»‹: " + light.getName());
    }
}

