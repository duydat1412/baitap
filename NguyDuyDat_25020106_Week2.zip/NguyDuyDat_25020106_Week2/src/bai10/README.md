## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
MÃ´ phá»ng sá»± tÆ°Æ¡ng tÃ¡c giá»¯a trung tÃ¢m Ä‘iá»u khiá»ƒn (Hub) vÃ  cÃ¡c thiáº¿t bá»‹ Ä‘Ã¨n thÃ´ng minh.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Ãp dá»¥ng **Method Overloading** cho `setBrightness` (nháº­n tham sá»‘ kiá»ƒu `int` hoáº·c `String` preset). Minh há»a sá»± **tÆ°Æ¡ng tÃ¡c giá»¯a cÃ¡c Ä‘á»‘i tÆ°á»£ng (Object Interaction)** khi `SmartLight` Ä‘Äƒng kÃ½ chÃ­nh nÃ³ vÃ o `CentralHub` thÃ´ng qua tham chiáº¿u `this`.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai10.code.main