## Tóm tắt ý tưởng chính
Mô tả một lớp có thuộc tính tự tham chiếu đến chính lớp đó.

## Hướng tiếp cận và Ưu điểm
Minh họa **Self-referencing relationships**. Thuộc tính `me` kiểu `Person` bên trong lớp `Person` cho phép xây dựng các cấu trúc dữ liệu liên kết hoặc các mối quan hệ logic giữa các thực thể của cùng một loại.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai8.code.main