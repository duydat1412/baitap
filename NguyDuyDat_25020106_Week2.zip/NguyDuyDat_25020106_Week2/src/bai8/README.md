## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
MÃ´ táº£ má»™t lá»›p cÃ³ thuá»™c tÃ­nh tá»± tham chiáº¿u Ä‘áº¿n chÃ­nh lá»›p Ä‘Ã³.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Minh há»a **Self-referencing relationships**. Thuá»™c tÃ­nh `me` kiá»ƒu `Person` bÃªn trong lá»›p `Person` cho phÃ©p xÃ¢y dá»±ng cÃ¡c cáº¥u trÃºc dá»¯ liá»‡u liÃªn káº¿t hoáº·c cÃ¡c má»‘i quan há»‡ logic giá»¯a cÃ¡c thá»±c thá»ƒ cá»§a cÃ¹ng má»™t loáº¡i.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai8.code.main