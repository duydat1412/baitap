﻿package bai8.code;
public class main {
    public static void main(String[] args) {
        Person p = new Person("Dat");
        p.setMe(p);
        System.out.println(p.getMe().getName());
        p=null;
    }
}

