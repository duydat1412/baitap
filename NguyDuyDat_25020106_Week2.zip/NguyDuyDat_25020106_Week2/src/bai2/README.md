## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
XÃ¢y dá»±ng lá»›p Sinh viÃªn vá»›i cÃ¡c thÃ´ng tin cÃ¡ nhÃ¢n vÃ  Ä‘iá»ƒm trung bÃ¬nh (GPA). Bao gá»“m nhiá»u constructor (Default, Parameterized, Copy Constructor).

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Ãp dá»¥ng tÃ­nh **ÄÃ³ng gÃ³i** thÃ´ng qua Getter/Setter. Sá»­ dá»¥ng **Constructor Overloading** Ä‘á»ƒ linh hoáº¡t trong viá»‡c táº¡o Ä‘á»‘i tÆ°á»£ng. Getter/Setter cho `GPA` cÃ³ kiá»ƒm tra miá»n giÃ¡ trá»‹ [0.0 - 4.0].

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai2.code.Student