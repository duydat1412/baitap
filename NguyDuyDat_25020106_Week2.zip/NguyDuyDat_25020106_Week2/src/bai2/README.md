## Tóm tắt ý tưởng chính
Xây dựng lớp Sinh viên với các thông tin cá nhân và điểm trung bình (GPA). Bao gồm nhiều constructor (Default, Parameterized, Copy Constructor).

## Hướng tiếp cận và Ưu điểm
Áp dụng tính **Đóng gói** thông qua Getter/Setter. Sử dụng **Constructor Overloading** để linh hoạt trong việc tạo đối tượng. Getter/Setter cho `GPA` có kiểm tra miền giá trị [0.0 - 4.0].

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai2.code.Student