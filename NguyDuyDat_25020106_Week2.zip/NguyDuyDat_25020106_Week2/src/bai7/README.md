## Tóm tắt ý tưởng chính
Hệ thống quản lý sản phẩm trong kho với khả năng bảo mật thông tin danh sách sản phẩm.

## Hướng tiếp cận và Ưu điểm
Áp dụng kỹ thuật **Defensive Copying** trong phương thức `getItems` và constructor của `Inventory`. Việc tạo bản sao mới của mảng và đối tượng giúp bảo vệ cấu trúc dữ liệu bên trong không bị sửa đổi từ bên ngoài.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai7.code.main