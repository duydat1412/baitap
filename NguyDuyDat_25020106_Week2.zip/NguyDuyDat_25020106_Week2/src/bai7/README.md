## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
Há»‡ thá»‘ng quáº£n lÃ½ sáº£n pháº©m trong kho vá»›i kháº£ nÄƒng báº£o máº­t thÃ´ng tin danh sÃ¡ch sáº£n pháº©m.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Ãp dá»¥ng ká»¹ thuáº­t **Defensive Copying** trong phÆ°Æ¡ng thá»©c `getItems` vÃ  constructor cá»§a `Inventory`. Viá»‡c táº¡o báº£n sao má»›i cá»§a máº£ng vÃ  Ä‘á»‘i tÆ°á»£ng giÃºp báº£o vá»‡ cáº¥u trÃºc dá»¯ liá»‡u bÃªn trong khÃ´ng bá»‹ sá»­a Ä‘á»•i tá»« bÃªn ngoÃ i.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai7.code.main