package bai7.code;
public class Product {
    private int id;
    private String name;
    private double price;

    public Product(int id,String name,double price) {
        this.id = id;
        this.name=name;
        this.price=price;
    }
    public int getId() {
        return this.id;
    }
    public String getName() {
        return this.name;
    }
    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price=price;
    }
    @Override
    public String toString() {
        return "ProductId = " + id + " ||| "
                + "ProductName = " + name + " ||| "
                + "ProductPrice = " + price;
    }
}

