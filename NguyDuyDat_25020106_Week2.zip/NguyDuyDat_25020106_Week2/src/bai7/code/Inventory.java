﻿package bai7.code;
public class Inventory {
    private Product[] items;

    public Inventory(Product[] initialItems) {
        this.items = new Product[initialItems.length];
        for (int i = 0;i<initialItems.length;i++) {
            Product p = initialItems[i];
                this.items[i]= new Product(p.getId(),p.getName(),p.getPrice());
        }
    }
    public Product[] getItems() {
        Product[] newList = new Product[items.length];
        for (int i =0 ;i<items.length;i++) {
            Product p = items[i];
            newList[i] = new Product(p.getId(),p.getName(),p.getPrice());
        }
        return newList;
    }
}

