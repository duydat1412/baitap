﻿package bai7.code;
public class main {
    public static void main(String[] args) {
        Product p1 = new Product(1412, "laptop", 1000.0);
        Product p2 = new Product(2910, "keyboard", 200.0);

        Product[] arr = {p1, p2};

        Inventory kho = new Inventory(arr);

        arr[0].setPrice(5000);

        System.out.println("MANG GOC ARR : ");
        for (Product p : arr) {
            System.out.println(p);
        }
        System.out.println("KHO HANG : ");
        Product[] khoItems = kho.getItems();  // Láº¥y máº£ng tá»« kho
        for (Product p : khoItems) {
            System.out.println(p);
        }
        System.out.println("=> Kho hang khong bi thay doi => safe ");
    }
}
