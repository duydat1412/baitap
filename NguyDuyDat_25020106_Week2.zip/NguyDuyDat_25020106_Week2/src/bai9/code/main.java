package bai9.code;

import java.util.Scanner;
public class main {
    public static  void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nháº­p thÃ´ng tin sáº£n pháº©m 1 ");
        System.out.print("TÃªn: ");
        String name1 = sc.nextLine();
        System.out.print("GiÃ¡: ");
        double price1 = sc.nextDouble();
        System.out.print("Sá»‘ lÆ°á»£ng: ");
        int quantity1 = sc.nextInt();
        System.out.print("Giáº£m giÃ¡: ");
        double discount1 = sc.nextDouble();
        sc.nextLine();
        Product p1 = new Product(name1,price1,quantity1,discount1);
        System.out.println("Táº¡o thÃ nh cÃ´ng sáº£n pháº©m " + name1);
        System.out.println("-----------------------------");

        System.out.println("Nháº­p thÃ´ng tin sáº£n pháº©m 2 ");
        System.out.print("TÃªn: ");
        String name2 = sc.nextLine();
        System.out.print("GiÃ¡: ");
        double price2 = sc.nextDouble();
        System.out.print("Sá»‘ lÆ°á»£ng: ");
        int quantity2 = sc.nextInt();
        System.out.print("Giáº£m giÃ¡: ");
        double discount2 = sc.nextDouble();
        sc.nextLine();
        Product p2 = new Product(name2,price2,quantity2,discount2);
        System.out.println("Táº¡o thÃ nh cÃ´ng sáº£n pháº©m " + name2);
        System.out.println("-----------------------------");
        System.out.println("Nháº­p sá»‘ lÆ°á»£ng cáº§n mua cho p1 : ");
        int amount1 = sc.nextInt();
        p1.sell(amount1);
        System.out.println("Nhap so luong can mua cho p2 : ");
        int amount2 = sc.nextInt();
        p2.sell(amount2);
        System.out.println("-----------------------------");
        System.out.println("Final price cá»§a p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price cá»§a p2 :");
        System.out.println(p2.calculateFinalPrice());
        Product.updateTaxRate(0.08);
        System.out.println("-----------------------------");
        System.out.println("Final price sau khi thay taxRate ");
        System.out.println("Final price cá»§a p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price cá»§a p2 :");
        System.out.println(p2.calculateFinalPrice());
        p1.updateDiscount(10.0);
        System.out.println("-----------------------------");
        System.out.println("Final price sau khi thay discount cá»§a p1");
        System.out.println("Final price cá»§a p1 :");
        System.out.println(p1.calculateFinalPrice());
        System.out.println("Final price cá»§a p2 :");
        System.out.println(p2.calculateFinalPrice());
        System.out.println("-----------------------------");
        System.out.println("Tá»•ng doanh thu lÃ  : ");
        System.out.println(Product.totalRevenueGet());


    }
}

