## Tóm tắt ý tưởng chính
Quản lý thông tin sản phẩm và tính toán doanh thu tổng dựa trên doanh số bán hàng.

## Hướng tiếp cận và Ưu điểm
Sử dụng từ khóa **static** cho `taxRate` và `totalRevenue`. Thành phần tĩnh giúp quản lý dữ liệu dùng chung cho toàn bộ các instance của lớp (Class-level data), phù hợp cho việc quản lý các hằng số hoặc dữ liệu tích lũy toàn cục.

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai9.code.main