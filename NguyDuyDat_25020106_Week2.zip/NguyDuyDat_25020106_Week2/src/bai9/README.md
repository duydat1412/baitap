## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
Quáº£n lÃ½ thÃ´ng tin sáº£n pháº©m vÃ  tÃ­nh toÃ¡n doanh thu tá»•ng dá»±a trÃªn doanh sá»‘ bÃ¡n hÃ ng.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Sá»­ dá»¥ng tá»« khÃ³a **static** cho `taxRate` vÃ  `totalRevenue`. ThÃ nh pháº§n tÄ©nh giÃºp quáº£n lÃ½ dá»¯ liá»‡u dÃ¹ng chung cho toÃ n bá»™ cÃ¡c instance cá»§a lá»›p (Class-level data), phÃ¹ há»£p cho viá»‡c quáº£n lÃ½ cÃ¡c háº±ng sá»‘ hoáº·c dá»¯ liá»‡u tÃ­ch lÅ©y toÃ n cá»¥c.

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai9.code.main