## Tóm tắt ý tưởng chính
Mô phỏng hệ thống quản lý tài khoản ngân hàng đơn giản với các tính năng mở tài khoản, nạp tiền, rút tiền và kiểm tra số dư.

## Hướng tiếp cận và Ưu điểm
Sử dụng **Private Access Modifier** cho thuộc tính `balance` để thực hiện tính **Đóng gói (Encapsulation)**. Kiểm soát logic nghiệp vụ trong các phương thức `deposit` và `withdraw` để đảm bảo tính toàn vẹn dữ liệu (không nạp/rút số tiền âm, không rút quá số dư).

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai1.code.BankAccount