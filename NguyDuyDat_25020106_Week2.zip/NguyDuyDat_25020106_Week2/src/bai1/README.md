## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
MÃ´ phá»ng há»‡ thá»‘ng quáº£n lÃ½ tÃ i khoáº£n ngÃ¢n hÃ ng Ä‘Æ¡n giáº£n vá»›i cÃ¡c tÃ­nh nÄƒng má»Ÿ tÃ i khoáº£n, náº¡p tiá»n, rÃºt tiá»n vÃ  kiá»ƒm tra sá»‘ dÆ°.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Sá»­ dá»¥ng **Private Access Modifier** cho thuá»™c tÃ­nh `balance` Ä‘á»ƒ thá»±c hiá»‡n tÃ­nh **ÄÃ³ng gÃ³i (Encapsulation)**. Kiá»ƒm soÃ¡t logic nghiá»‡p vá»¥ trong cÃ¡c phÆ°Æ¡ng thá»©c `deposit` vÃ  `withdraw` Ä‘á»ƒ Ä‘áº£m báº£o tÃ­nh toÃ n váº¹n dá»¯ liá»‡u (khÃ´ng náº¡p/rÃºt sá»‘ tiá»n Ã¢m, khÃ´ng rÃºt quÃ¡ sá»‘ dÆ°).

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai1.code.BankAccount