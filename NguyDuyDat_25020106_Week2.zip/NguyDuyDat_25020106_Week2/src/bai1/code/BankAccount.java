﻿package bai1.code;
public class BankAccount {
	private String 	accountNumber;
	private double balance = 0.0;
	private String ownerName;

	public void openAccount(String accNum, String owner, double bl) {
		this.accountNumber = accNum;
		this.ownerName = owner;
		if (bl<0){
			this.balance = 0;
			System.out.println("error");
		}else this.balance = bl;
	}
	public void deposit(double amount) {
		if (amount > 0) {
			this.balance += amount;
		} else System.out.println("So tien nap vao phai lon hon 0");
	}
	public void withdraw(double amount) {
		if (amount > 0 && amount <= this.balance) {
			this.balance-=amount;
			System.out.println("true");;
		} else System.out.println("false");;
	}
	public void getBalance() {
		System.out.println(this.balance);
	}
	public static void main(String[] args) {
		BankAccount myAccount = new BankAccount();
		myAccount.openAccount("101202303", "Nguyen Van A",0);
		myAccount.deposit(500.0);
		myAccount.getBalance();
		myAccount.deposit(-100);
		myAccount.withdraw(550.0);
		myAccount.withdraw(200);
	}
}
