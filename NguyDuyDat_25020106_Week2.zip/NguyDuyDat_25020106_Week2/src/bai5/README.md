# Bài 5: Equals Method

## Tóm tắt ý tưởng chính
Xử lý việc so sánh nội dung giữa hai đối tượng sách thay vì so sánh địa chỉ bộ nhớ bằng cách ghi đè phương thức `equals`.

## Hướng tiếp cận và Ưu điểm
Thực hiện **Ghi đè (Overriding)** phương thức `equals` từ lớp cha `Object`. Đây là kỹ thuật quan trọng để định nghĩa logic so sánh bằng nhau (Equality) dựa trên các giá trị thuộc tính cụ thể (`title`, `author`, `price`), thay vì chỉ so sánh địa chỉ vùng nhớ.
Cách tiếp cận này giúp mã nguồn linh hoạt hơn khi cần kiểm tra sự trùng lặp dữ liệu trong các cấu trúc như List hay Set.

## Cách chạy
- Sử dụng script bash: `./run.sh`
- Class chứa hàm main thực thi: `bai5.code.Book`

---

## 5. Kết quả phân tích (Trả lời câu hỏi)

### 5.1. Sự khác nhau giữa `==` và `equals()`

| Đặc điểm | Toán tử `==` | Phương thức `equals()` (Sau khi override) |
| :--- | :--- | :--- |
| **Loại so sánh** | So sánh tham chiếu (Reference comparison). | So sánh nội dung/giá trị (Content comparison). |
| **Cơ chế** | Kiểm tra xem hai biến có cùng trỏ tới một địa chỉ vùng nhớ trong Heap hay không. | Kiểm tra các giá trị thuộc tính (`title`, `author`, `price`) của hai đối tượng có giống nhau hay không. |
| **Kết quả ví dụ** | Hai đối tượng được tạo riêng biệt (`new`) với cùng dữ liệu sẽ trả về `false`. | Hai đối tượng có cùng dữ liệu (dù tạo từ 2 lệnh `new` khác nhau) sẽ trả về `true`. |

- **Kết luận:** Trong Java, để so sánh hai đối tượng có "giống nhau" về mặt dữ liệu hay không, ta nên sử dụng `equals()` thay vì `==`. Toán tử `==` chỉ nên dùng cho các kiểu dữ liệu nguyên thủy (primitive types) hoặc khi muốn kiểm tra xem hai biến có thực sự là cùng một thực thể hay không.