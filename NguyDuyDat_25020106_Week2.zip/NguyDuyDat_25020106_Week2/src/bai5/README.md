## TÃ³m táº¯t Ã½ tÆ°á»Ÿng chÃ­nh
Xá»­ lÃ½ viá»‡c so sÃ¡nh ná»™i dung giá»¯a hai Ä‘á»‘i tÆ°á»£ng sÃ¡ch thay vÃ¬ so sÃ¡nh Ä‘á»‹a chá»‰ bá»™ nhá»›.

## HÆ°á»›ng tiáº¿p cáº­n vÃ  Æ¯u Ä‘iá»ƒm
Thá»±c hiá»‡n **Ghi Ä‘Ã¨ (Overriding)** phÆ°Æ¡ng thá»©c `equals` tá»« lá»›p cha `Object`. ÄÃ¢y lÃ  ká»¹ thuáº­t quan trá»ng Ä‘á»ƒ Ä‘á»‹nh nghÄ©a logic so sÃ¡nh báº±ng nhau (Equality) dá»±a trÃªn cÃ¡c giÃ¡ trá»‹ thuá»™c tÃ­nh cá»¥ thá»ƒ (`title`, `author`, `price`).

So vá»›i láº­p trÃ¬nh hÆ°á»›ng thá»§ tá»¥c, cÃ¡ch tiáº¿p cáº­n nÃ y giÃºp mÃ£ nguá»“n dá»… báº£o trÃ¬, má»Ÿ rá»™ng vÃ  giáº£m thiá»ƒu rá»§i ro lá»—i dá»¯ liá»‡u nhá» viá»‡c tÃ¡ch biá»‡t rÃµ rÃ ng giá»¯a giao diá»‡n sá»­ dá»¥ng (Public methods) vÃ  chi tiáº¿t triá»ƒn khai bÃªn trong (Private fields).

## CÃ¡ch cháº¡y
- Sá»­ dá»¥ng script bash báº¯t buá»™c: ./run.sh
- Class chá»©a hÃ m main thá»±c thi: bai5.code.Book