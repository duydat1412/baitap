## Tóm tắt ý tưởng chính
Xử lý việc so sánh nội dung giữa hai đối tượng sách thay vì so sánh địa chỉ bộ nhớ.

## Hướng tiếp cận và Ưu điểm
Thực hiện **Ghi đè (Overriding)** phương thức `equals` từ lớp cha `Object`. Đây là kỹ thuật quan trọng để định nghĩa logic so sánh bằng nhau (Equality) dựa trên các giá trị thuộc tính cụ thể (`title`, `author`, `price`).

So với lập trình hướng thủ tục, cách tiếp cận này giúp mã nguồn dễ bảo trì, mở rộng và giảm thiểu rủi ro lỗi dữ liệu nhờ việc tách biệt rõ ràng giữa giao diện sử dụng (Public methods) và chi tiết triển khai bên trong (Private fields).

## Cách chạy
- Sử dụng script bash bắt buộc: ./run.sh
- Class chứa hàm main thực thi: bai5.code.Book