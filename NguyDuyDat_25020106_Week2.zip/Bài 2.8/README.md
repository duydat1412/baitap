# Bài 2.8: Object Reference và Garbage Collection

## 1. Sau khi `setMe(p)` có bao nhiêu đối tượng Person tồn tại trong bộ nhớ?

**Trả lời:** Có **1 object** duy nhất trên Heap, nhưng có **2 tham chiếu** trỏ vào nó:
- Biến `p` trên Stack
- Field `me` bên trong chính object đó


## 2. Sau dòng lệnh `p = null`, đối tượng Person có bị xóa ngay lập tức không?

**Trả lời:** **Không bị xóa ngay.** Vì:
- `p = null` chỉ hủy tham chiếu từ Stack
- Field `me` bên trong object vẫn tự trỏ vào chính nó (self-reference)
- Garbage Collector (GC) phát hiện object này không còn được truy cập từ bên ngoài → tự động thu hồi sau, không xác định chính xác thời điểm nào

**GC hoạt động như thế nào?**
GC là cơ chế tự động của JVM, có nhiệm vụ tìm và xóa các object không còn được sử dụng khỏi Heap. GC không chạy ngay lập tức mà chạy khi JVM thấy cần thiết (ví dụ: bộ nhớ sắp đầy).

## 3. Đối tượng Person có thể được truy cập lại không?

**Trả lời:** **Không.** Sau `p = null`, không còn biến nào từ Stack trỏ vào object nữa. Dù object vẫn còn tồn tại trên Heap cho đến khi GC dọn dẹp, nhưng lập trình viên không có cách nào truy cập lại được.


## 4. Sơ đồ bộ nhớ (Stack và Heap)

### Trước `p = null`

```
Stack              Heap
┌──────┐          ┌─────────────────────┐
│  p ──┼─────────►│ name = "Alice"      │◄─┐
└──────┘          │ me ─────────────────┼──┘
                  └─────────────────────┘
```

- Biến `p` trên Stack trỏ vào object trên Heap
- Field `me` bên trong object tự trỏ ngược lại chính nó → tạo thành vòng tròn (self-reference)

### Sau `p = null`

```
Stack              Heap
┌──────────┐      ┌─────────────────────┐
│  p = null│      │ name = "Alice"      │◄─┐
└──────────┘      │ me ─────────────────┼──┘
                  └─────────────────────┘
                       (GC sẽ dọn sau)
```

- Biến `p` không còn trỏ vào object nữa.
- Object vẫn tồn tại trên Heap nhưng không thể truy cập từ bên ngoài.
- GC sẽ tự động thu hồi vùng nhớ này sau.

*NguyDuyDat_25020106_IT6*