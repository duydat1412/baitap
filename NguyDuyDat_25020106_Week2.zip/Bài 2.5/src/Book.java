public class Book {
    private String title;
    private String author;
    private double price;

    public Book(String title, String author, double price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }

    @Override
    public boolean equals(Object obj) {
        Book book = (Book) obj;
        if ((this.title == book.title) && (this.author == book.author) && (this.price == book.price)) {
            return true;
        } else return false;
    }
    public static void main(String[] args) {
        Book book1 = new Book("HumHum","Hung",18);
        Book book2 = new Book("HumHum","Hung",18);
        System.out.println(book2.equals(book1));
    }
}
