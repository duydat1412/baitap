SAI - Shallow copy, hacker có thể sửa mảng gốc
public Transaction[] getHistory() {
return history; // trả thẳng reference
}

ĐÚNG - Deep copy
public Transaction[] getHistory() {
Transaction[] copy = new Transaction[history.length];
for (int i = 0; i < history.length; i++) {
copy[i] = history[i]; // Transaction immutable nên copy reference là đủ
}
return copy;