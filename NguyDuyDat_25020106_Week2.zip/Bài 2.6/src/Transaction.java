public final class Transaction {
        private final String transactionId;
        private final String amount;
        private final String timestamp;

        public Transaction(String transactionId, String amount,String timestamp) {
            this.transactionId=transactionId;
            this.amount=amount;
            this.timestamp=timestamp;
        }
        @Override
    public String toString() {
            return "transactionId = " + transactionId + " ||| "
                    + "amount = "+ amount + " ||| "
                    + "timestamp = " + timestamp;
        }
}
