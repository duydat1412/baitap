// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static int secondLargest(int[] arr) {

        if (arr.length < 2) return -1;
        int lonNhat = Integer.MIN_VALUE;
        int lonThuHai = Integer.MIN_VALUE;
        for (int i = 0 ; i < arr.length; i++) {
            if (arr[i] > lonNhat) {
                lonThuHai = lonNhat;
                lonNhat = arr[i];

            } else if ( arr[i] > lonThuHai && arr[i] != lonNhat) {
                lonThuHai= arr[i];
            }
        }
        if (lonThuHai ==Integer.MIN_VALUE) return -1;
        return lonThuHai;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.secondLargest(new int[]{1, 3, 5, 2, 4}));
        System.out.println(solution.secondLargest(new int[]{5, 5, 5}));
        System.out.println(solution.secondLargest(new int[]{7}));
        System.out.println(solution.secondLargest(new int[]{-1, -2, -3}));

    }
}