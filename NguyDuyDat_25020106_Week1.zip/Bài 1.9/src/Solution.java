// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static int sumOfDigits(int n) {
        if ( n == 0 ) return 0;
        if ( n < 0 ) n= -n;
        long sum =0;
        while (n!=0) {
            long socuoi = n %10;
            sum = sum + socuoi;
            n /= 10;
        }
        return (int) sum;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.sumOfDigits(123));
        System.out.println(solution.sumOfDigits(-456));
        System.out.println(solution.sumOfDigits(0));

    }
}