public class HelloName {
	public static void main(String[] arg) {
		
		System.out.print("Hello, Dat");
		
	}
}