// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static Boolean isPalindrome(int n) {
        if (n <0 || n %10 == 0 && n != 0) return false;
        long reversed =0;
        while(n!=0) {
            long socuoi = n % 10;
            reversed = reversed * 10 + socuoi;
            n /= 10;
        }
        return reversed == n;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.isPalindrome(121));
        System.out.println(solution.isPalindrome(-121));
        System.out.println(solution.isPalindrome(10));
        System.out.println(solution.isPalindrome(0));
    }
}