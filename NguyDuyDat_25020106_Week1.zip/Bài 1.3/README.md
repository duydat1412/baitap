# Bài 1.3: Phân tích Object

a) Lớp BankAccount
```java
public class BankAccount {
  private String accountNumber;
  private String ownerName;
  private double balance = 0.0;
  public void openAccount(String accNum, String owner) {
    this.accountNumber = accNum;
    this.ownerName = owner;
  }
  public void deposit(double amount) {
    this.balance += amount;
  }
  public boolean withdraw(double amount) {
    if (this.balance >= amount) {
      this.balance -= amount;
      return true;
    }
    return false;
  }
  public static void main(String[] args) {
    BankAccount myAccount = new BankAccount();
    myAccount.openAccount("101202303", "Nguyen Van A");
    myAccount.deposit(500.0);
    myAccount.withdraw(150.0);
  }
}
```
*Đối tượng là BankAccount.
*Hành vi của một đối tượng bao gồm deposit và withdraw tiền vào tài khoản ngân hàng, và openAccount ( mở tài khoản ngân hàng ).
*Trạng thái của một BankAccount bao gồm:
+ accountNumber
+ ownerName
+ balance
*Định danh của đối tượng là myAccount.


--------------------------------------------------

b) Lớp SmartFan
```java
public class SmartFan {
  private String brand = "Xiaomi";
  private boolean isPowerOn = false;
  private int speedLevel = 0; // Mức từ 1 đến 3
  public void turnOn() {
    this.isPowerOn = true;
  }
  public void turnOff() {
    this.isPowerOn = false;
    this.speedLevel = 0;
  }
  public void setSpeed(int newSpeed) {
    // Chỉ đổi tốc độ nếu quạt đang bật
    if (this.isPowerOn == true) {
      this.speedLevel = newSpeed;
    }
  }
  public static void main(String[] args) {
    SmartFan livingRoomFan = new SmartFan();
    livingRoomFan.turnOn();
    livingRoomFan.setSpeed(2);
    SmartFan bedroomFan = new SmartFan();
    bedroomFan.setSpeed(3);
    bedroomFan.turnOn();
  }
}
```

*Đối tượng là SmartFan
*Hành vi của một chiếc SmartFan bao gồm turnOn ( bật ), turnOff ( tắt ) và setSpeed ( điều chỉnh tốc độ quạt, và chỉ có thể thay đổi nếu quạt đang bật ).
*Trạng thái của một chiếc SmartFan bao gồm brand, isPowerOn, và speedLevel.
*Ở đây gồm 2 đối tượng SmartFan mang 2 định danh khác nhau là :
+ livingRoomFan
+ bedroomFan
