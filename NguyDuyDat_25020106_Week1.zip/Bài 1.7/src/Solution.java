// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static int reverse(int n) {

        long reversed =0;
        while (n!=0){
            long socuoi = n%10;
            reversed = reversed * 10 + socuoi;
            n = n / 10; // xóa số cuối đã lấy.

        }
        return (int) reversed;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.reverse(291));
        System.out.println(solution.reverse(-291));
        System.out.println(solution.reverse(2910));
        System.out.println(solution.reverse(29102008));
    }
}