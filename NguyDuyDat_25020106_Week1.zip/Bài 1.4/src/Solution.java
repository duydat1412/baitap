// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static long fibonacci(long n) {

        if (n<0){
            return -1;
        } else if (n==0) {
            return 0;
        } else if (n==1) {
            return 1;
        } else if (n>100) {
            return -1;
        }
        long fib0 =0;
        long fib1=1;
        long fibn =0;
        for (long i = 2;i<=n;i++) {
            if (Long.MAX_VALUE - fib1 < fib0){
                return Long.MAX_VALUE;
            }
            fibn=fib1+fib0;
            fib0=fib1;
            fib1=fibn;

        }
        return fibn;
    }
    public static void main(String[] args){
        Solution solution = new Solution();
        System.out.println(solution.fibonacci(-1));
        System.out.println(solution.fibonacci(0));
        System.out.println(solution.fibonacci(1));
        System.out.println(solution.fibonacci(29));
        System.out.println(solution.fibonacci(101));
    }
}