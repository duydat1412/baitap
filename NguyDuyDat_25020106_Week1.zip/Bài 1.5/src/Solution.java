// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static int gcd(int a, int b) {

        a = Math.abs(a);
        b = Math.abs(b);
        while(b!=0){
            int temp = b;
            b = a%b;
            a=temp;

        }
        return a;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.gcd(14,29));
        System.out.println(solution.gcd(-14,29));
        System.out.println(solution.gcd(14,0));
        System.out.println(solution.gcd(0,0));
    }
}