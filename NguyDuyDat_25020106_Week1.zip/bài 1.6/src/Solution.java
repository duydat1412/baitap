// Import your library
// Do not change the name of the Solution class
public class Solution {

    public static Boolean isPrime(int n) {

        if (n<=1){
            return false;
        } else if ( n==2 ) {
            return true;
        }
        for (int i = 3; i*i<=n;i++){

         if (n%i==0){
          return false;
         }
        }
        return true;
    }
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.isPrime(-10));
        System.out.println(solution.isPrime(2));
        System.out.println(solution.isPrime(9973));
    }
}